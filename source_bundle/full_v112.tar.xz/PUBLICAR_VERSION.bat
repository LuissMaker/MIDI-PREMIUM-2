@echo off
setlocal
cd /d "%~dp0"
echo MIDI Premium 2 - Publicar version
where git >nul 2>&1 || (echo [ERROR] Git no esta instalado.& pause & exit /b 1)
for /f "tokens=2 delims=\"" %%V in ('findstr /b "__version__" app_source\app\version.py') do set "FULLVER=%%V"
for /f "tokens=1" %%V in ("%FULLVER%") do set "VER=%%V"
if not defined VER (echo [ERROR] No se pudo leer la version.& pause & exit /b 1)
echo Version detectada: %VER%
git add .
git commit -m "Release v%VER%"
if errorlevel 1 echo [AVISO] No habia cambios nuevos para commit.
git push origin main || exit /b 1
git tag -f "v%VER%"
git push origin "v%VER%" --force || exit /b 1
echo.
echo Publicacion solicitada. GitHub Actions generara el portable y el instalador.
pause
