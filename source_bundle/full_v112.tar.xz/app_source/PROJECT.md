# MIDI Premium 2

## Especificación Oficial del Proyecto

**Versión del documento:** 1.0\
**Estado:** Documento Maestro (PROJECT.md)

------------------------------------------------------------------------

# Objetivo

MIDI Premium 2 es una aplicación profesional para Windows inspirada en
Elgato Stream Deck, utilizando controladores MIDI como superficie de
control.

El objetivo no es crear un prototipo, sino un software estable,
mantenible y preparado para crecer durante años.

La prioridad absoluta es la **estabilidad**.

> Ninguna función nueva podrá romper una función existente.

------------------------------------------------------------------------

# Filosofía

-   Todo debe configurarse desde la interfaz.
-   Nunca editar archivos manualmente.
-   Interfaz moderna, intuitiva y profesional.
-   Código limpio y modular.
-   Arquitectura preparada para crecer.

------------------------------------------------------------------------

# Arquitectura General

El proyecto será **100% Portable**.

    MIDI Premium 2/
    │
    ├── app/
    ├── assets/
    ├── config/
    ├── profiles/
    ├── logs/
    ├── runtime/
    ├── plugins/
    ├── backups/
    │
    ├── PROJECT.md
    ├── ROADMAP.md
    ├── CHANGELOG.md
    ├── README.md
    ├── main.py
    ├── INICIAR.bat
    ├── DEV.bat
    └── PORTABLE.flag

No utilizar AppData.

Toda la información debe permanecer dentro de la carpeta del programa.

------------------------------------------------------------------------

# Ramas del Proyecto

## STABLE

Versión utilizada para streaming.

Solo contiene funciones completamente probadas.

## DEV

Versión donde se desarrolla.

Todas las funciones nuevas nacen aquí.

Solo cuando una función esté completamente validada pasará a STABLE.

------------------------------------------------------------------------

# Flujo de Desarrollo

Toda función seguirá obligatoriamente este flujo:

1.  Diseño.
2.  Análisis del impacto.
3.  Aprobación.
4.  Implementación.
5.  Pruebas.
6.  Corrección.
7.  Integración en DEV.
8.  Validación.
9.  Paso a STABLE.

La IA **no debe escribir código inmediatamente**.

Primero debe presentar:

-   Objetivo.
-   Archivos afectados.
-   Riesgos.
-   Plan de implementación.

Y esperar aprobación.

------------------------------------------------------------------------

# Interfaz

Inspiración:

-   Elgato Stream Deck
-   OBS Studio
-   Photoshop

Tema oscuro.

Paneles ocultables.

Modo Stream.

------------------------------------------------------------------------

# Sistema MIDI

Arquitectura:

    Listener
        ↓
    Parser
        ↓
    Router
        ↓
    Dispatcher
        ↓
    Actions

La lógica MIDI nunca deberá mezclarse con la interfaz.

------------------------------------------------------------------------

# Pads

Versión inicial:

-   16 Pads.
-   Bank A.
-   Bank B.
-   Mapa fijo.
-   Sin calibración.
-   Sin aprendizaje.

Las páginas llegarán únicamente cuando el motor MIDI sea completamente
estable.

------------------------------------------------------------------------

# Editor

Cada pad podrá configurar:

-   Nombre
-   Icono
-   Color
-   Acción
-   Descripción
-   Programa
-   Archivo
-   URL
-   OBS
-   Atajos
-   Macros

------------------------------------------------------------------------

# OBS

Debe incluir:

-   Conectar
-   Desconectar
-   Probar conexión
-   Reconexión automática
-   Guardar contraseña
-   Mostrar contraseña
-   Indicadores visuales

Nunca bloquear la interfaz.

------------------------------------------------------------------------

# Perfiles

Cada perfil almacena:

-   Acciones
-   Configuración
-   Preferencias
-   Tema
-   Estado del programa

------------------------------------------------------------------------

# Portable

Toda la información debe almacenarse únicamente en:

-   config/
-   profiles/
-   logs/
-   backups/

------------------------------------------------------------------------

# Logs

    logs/
        latest.log
        midi.log
        obs.log
        errors.log

------------------------------------------------------------------------

# Actualizador

Proceso:

1.  Crear Backup.
2.  Cerrar aplicación.
3.  Limpiar archivos temporales.
4.  Copiar nueva versión.
5.  Restaurar perfiles.
6.  Verificar versión.

Nunca copiar archivos sobre versiones mezcladas.

------------------------------------------------------------------------

# Reglas de Código

-   Código modular.
-   Una responsabilidad por clase.
-   Archivos pequeños.
-   Sin dependencias innecesarias.
-   Código fácil de mantener.

------------------------------------------------------------------------

# Lecciones Aprendidas

Durante el desarrollo se comprobó que agregar simultáneamente:

-   Páginas.
-   Calibración.
-   Aprendizaje MIDI.
-   Controles extra.
-   Múltiples motores.

provocó regresiones importantes.

Por ello se decidió volver a una base estable antes de continuar.

------------------------------------------------------------------------

# Regla de Oro

> Antes de implementar cualquier función, evaluar si respeta la
> arquitectura existente.

Si requiere modificar varios módulos principales, primero deberá
proponerse una solución de diseño y esperar aprobación.

------------------------------------------------------------------------

# Visión

El objetivo no es terminar rápido.

El objetivo es construir un software profesional, estable y mantenible
durante muchos años.
