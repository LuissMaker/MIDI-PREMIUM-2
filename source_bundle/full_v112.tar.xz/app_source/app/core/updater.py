from __future__ import annotations

import json
import os
import subprocess
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from PySide6.QtCore import QObject, Signal

from app.version import __version__

REPOSITORY = "LuissMaker/MIDI-PREMIUM-2"
MANIFEST_URL = f"https://raw.githubusercontent.com/{REPOSITORY}/main/latest.json"
USER_AGENT = "MIDI-Premium-2-Updater/1.1"


def version_key(value: str) -> tuple[int, ...]:
    clean = str(value or "").strip().lower().lstrip("v")
    numeric = clean.split()[0]
    parts: list[int] = []
    for item in numeric.split("."):
        digits = "".join(ch for ch in item if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts or [0])


def current_version() -> str:
    return str(__version__).split()[0]


def fetch_manifest(timeout: int = 10) -> dict[str, Any]:
    req = urllib.request.Request(MANIFEST_URL, headers={"User-Agent": USER_AGENT, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        payload = response.read().decode("utf-8-sig")
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("El manifiesto de actualización no es válido.")
    return data


def update_available(manifest: dict[str, Any]) -> bool:
    latest = str(manifest.get("version", "") or "").strip()
    return bool(latest) and version_key(latest) > version_key(current_version())


def setup_download_url(manifest: dict[str, Any]) -> str:
    explicit = str(manifest.get("setup_url", "") or "").strip()
    if explicit:
        return explicit
    repo = str(manifest.get("repo", REPOSITORY) or REPOSITORY).strip()
    tag = str(manifest.get("tag", "") or f"v{manifest.get('version', '')}").strip()
    asset = str(manifest.get("setup_asset", "") or f"MIDI_Premium_2_Setup_v{manifest.get('version', '')}.exe").strip()
    return f"https://github.com/{repo}/releases/download/{tag}/{asset}"


class UpdateService(QObject):
    check_finished = Signal(object, str, bool)
    download_progress = Signal(int)
    download_finished = Signal(str, str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._checking = False
        self._downloading = False

    def check_async(self, interactive: bool = False) -> bool:
        if self._checking:
            return False
        self._checking = True

        def run() -> None:
            try:
                manifest = fetch_manifest()
                self.check_finished.emit(manifest, "", interactive)
            except Exception as exc:
                self.check_finished.emit({}, str(exc), interactive)
            finally:
                self._checking = False

        threading.Thread(target=run, daemon=True, name="MidiPremiumUpdateCheck").start()
        return True

    def download_setup_async(self, manifest: dict[str, Any]) -> bool:
        if self._downloading:
            return False
        self._downloading = True

        def run() -> None:
            try:
                url = setup_download_url(manifest)
                version = str(manifest.get("version", "update") or "update")
                target = Path(tempfile.gettempdir()) / f"MIDI_Premium_2_Setup_v{version}.exe"
                req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                with urllib.request.urlopen(req, timeout=30) as response, target.open("wb") as fh:
                    total = int(response.headers.get("Content-Length", "0") or 0)
                    read = 0
                    while True:
                        chunk = response.read(1024 * 256)
                        if not chunk:
                            break
                        fh.write(chunk)
                        read += len(chunk)
                        if total:
                            self.download_progress.emit(max(0, min(100, int(read * 100 / total))))
                if not target.exists() or target.stat().st_size < 1024:
                    raise RuntimeError("El instalador descargado no es válido.")
                self.download_finished.emit(str(target), "")
            except Exception as exc:
                self.download_finished.emit("", str(exc))
            finally:
                self._downloading = False

        threading.Thread(target=run, daemon=True, name="MidiPremiumUpdateDownload").start()
        return True


def launch_installer(path: str) -> None:
    installer = str(Path(path))
    args = [installer, "/SILENT", "/CLOSEAPPLICATIONS", "/RESTARTAPPLICATIONS"]
    if os.name == "nt":
        # El instalador de Inno Setup solicitará elevación cuando sea necesaria.
        subprocess.Popen(args, close_fds=True)
    else:
        subprocess.Popen(args, close_fds=True)
