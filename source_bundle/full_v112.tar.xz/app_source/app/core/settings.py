from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


DEFAULT_SETTINGS: dict[str, Any] = {
    "window": {
        "width": 1180,
        "height": 760,
        "x": None,
        "y": None,
        "normal": {"width": 1180, "height": 760, "x": None, "y": None},
        "compact": {"width": 635, "height": 850, "x": None, "y": None},
        "pad_editor": {"width": 680, "height": 720},
        "knob_editor": {"width": 500, "height": 390},
    },
    "workspace": {
        "active_bank": "A",
        "selected_pad": 1,
        "active_profile": "General",
        "stream_mode": False,
        "compact_mode": True,
        "minimize_to_tray": True,
        "start_with_windows": False,
        "start_hidden_to_tray": True,
        "show_action_osd": True,
        "show_knob_osd": True,
        "osd_duration_ms": 1400,
        "knob_osd_duration_ms": 950,
        "osd_show_icon": True,
        "osd_show_bank": True,
    },
    "midi": {
        "preferred_device": "",
        "auto_connect": True,
        "auto_reconnect": True,
        "reconnect_interval_ms": 3000,
        "bindings": {
            "profile_prev": "",
            "profile_next": "",
            "bank_a": "",
            "bank_b": "",
            "bank_toggle": "",
            "show_hide": ""
        },
        "joystick": {
            "horizontal_signature": "",
            "vertical_signature": "",
            "left_action": "profile_prev",
            "right_action": "profile_next",
            "up_action": "bank_a",
            "down_action": "bank_b",
            "threshold": 0.65,
            "center_deadzone": 0.18,
            "cooldown_ms": 300
        },
    },
    "paths": {
        "photoshop_exe": "C:/Program Files/Adobe/Adobe Photoshop 2026/Photoshop.exe",
        "photoshop_scripts": "D:/SOGMA/Herramientas/midi/rutas jsx",
    },
    "updates": {
        "check_on_start": True,
    },
    "obs": {
        "host": "localhost",
        "port": 4455,
        "password_protected": "",
        "auto_connect": False,
        "auto_reconnect": True,
        "reconnect_interval_ms": 5000,
    },
}


class SettingsManager:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.data = self._load()

    def _load(self) -> dict[str, Any]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            data = deepcopy(DEFAULT_SETTINGS)
            self._write(data)
            return data

        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            loaded = {}

        result = deepcopy(DEFAULT_SETTINGS)
        for section, values in loaded.items():
            if isinstance(values, dict) and isinstance(result.get(section), dict):
                result[section].update(values)
            else:
                result[section] = values
        return result

    def save(self) -> None:
        self._write(self.data)

    def _write(self, data: dict[str, Any]) -> None:
        self.path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
