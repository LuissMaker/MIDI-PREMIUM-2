from __future__ import annotations

import base64
import ctypes
import os
from ctypes import wintypes


class DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_byte)),
    ]


def _blob(data: bytes) -> tuple[DATA_BLOB, object]:
    buffer = ctypes.create_string_buffer(data)
    blob = DATA_BLOB(
        len(data),
        ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)),
    )
    return blob, buffer


def protect_text(value: str) -> str:
    if not value:
        return ""

    raw = value.encode("utf-8")

    if os.name != "nt":
        return "portable:" + base64.b64encode(raw).decode("ascii")

    input_blob, input_buffer = _blob(raw)
    output_blob = DATA_BLOB()

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32

    result = crypt32.CryptProtectData(
        ctypes.byref(input_blob),
        "MIDI Premium 2",
        None,
        None,
        None,
        0,
        ctypes.byref(output_blob),
    )
    if not result:
        raise ctypes.WinError()

    try:
        protected = ctypes.string_at(
            output_blob.pbData,
            output_blob.cbData,
        )
        return "dpapi:" + base64.b64encode(protected).decode("ascii")
    finally:
        kernel32.LocalFree(output_blob.pbData)
        _ = input_buffer


def unprotect_text(value: str) -> str:
    if not value:
        return ""

    if value.startswith("portable:"):
        return base64.b64decode(value[9:]).decode("utf-8")

    if not value.startswith("dpapi:"):
        return ""

    if os.name != "nt":
        return ""

    encrypted = base64.b64decode(value[6:])
    input_blob, input_buffer = _blob(encrypted)
    output_blob = DATA_BLOB()

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32

    result = crypt32.CryptUnprotectData(
        ctypes.byref(input_blob),
        None,
        None,
        None,
        None,
        0,
        ctypes.byref(output_blob),
    )
    if not result:
        raise ctypes.WinError()

    try:
        raw = ctypes.string_at(
            output_blob.pbData,
            output_blob.cbData,
        )
        return raw.decode("utf-8")
    finally:
        kernel32.LocalFree(output_blob.pbData)
        _ = input_buffer
