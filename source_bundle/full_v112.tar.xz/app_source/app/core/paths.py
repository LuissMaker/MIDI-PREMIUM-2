from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AppPaths:
    root: Path
    config: Path
    profiles: Path
    logs: Path
    runtime: Path
    backups: Path
    app_root: Path

    @classmethod
    def detect(cls) -> "AppPaths":
        # app_root apunta a la carpeta ejecutable de esta build (DEV o STABLE).
        app_root = Path(__file__).resolve().parents[2]

        # Configuración/perfiles persistentes entre actualizaciones.
        # En Windows se guardan fuera de la carpeta de cada versión para que
        # al descomprimir v0.7.8/v0.8.0 no vuelvan a quedar vacíos.
        appdata = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA")
        if os.name == "nt" and appdata:
            root = Path(appdata) / "MIDI Premium 2"
        else:
            root = app_root / "user_data"

        obj = cls(
            root=root,
            config=root / "config",
            profiles=root / "profiles",
            logs=root / "logs",
            runtime=root / "runtime",
            backups=root / "backups",
            app_root=app_root,
        )
        obj._migrate_legacy_data()
        return obj

    def _migrate_legacy_data(self) -> None:
        """Importa una configuración anterior una sola vez cuando sea posible."""
        if self.config.exists() or self.profiles.exists():
            return

        candidates: list[Path] = [self.app_root]
        # Si las builds están una al lado de otra, busca la más reciente.
        base = self.app_root.parent.parent
        try:
            siblings = sorted(
                [candidate for p in base.glob("MIDI_Premium_2*") for candidate in (p / "STABLE", p / "DEV") if candidate.is_dir()],
                key=lambda x: x.stat().st_mtime,
                reverse=True,
            )
            candidates.extend(siblings)
        except OSError:
            pass

        for candidate in candidates:
            legacy_cfg = candidate / "config" / "settings.json"
            legacy_profiles = candidate / "profiles"
            if legacy_cfg.exists() or (legacy_profiles.exists() and any(legacy_profiles.glob("*.json"))):
                try:
                    self.config.mkdir(parents=True, exist_ok=True)
                    self.profiles.mkdir(parents=True, exist_ok=True)
                    if legacy_cfg.exists():
                        shutil.copy2(legacy_cfg, self.config / "settings.json")
                    if legacy_profiles.exists():
                        for f in legacy_profiles.glob("*.json"):
                            shutil.copy2(f, self.profiles / f.name)
                    return
                except OSError:
                    continue

    def ensure(self) -> None:
        for folder in (
            self.config,
            self.profiles,
            self.logs,
            self.runtime,
            self.backups,
        ):
            folder.mkdir(parents=True, exist_ok=True)
