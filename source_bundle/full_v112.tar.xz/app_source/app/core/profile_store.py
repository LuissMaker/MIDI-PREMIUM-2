from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ProfileStore:
    def __init__(self, folder: Path) -> None:
        self.folder = folder
        self.folder.mkdir(parents=True, exist_ok=True)

    def list_profiles(self) -> list[str]:
        result = [path.stem for path in self.folder.glob("*.json")]
        if not result:
            self.create("General")
            result = ["General"]
        return sorted(result, key=str.lower)

    def create(self, name: str) -> None:
        path = self.folder / f"{name}.json"
        if not path.exists():
            path.write_text(
                json.dumps(
                    {
                        "name": name,
                        "icon": "",
                        "pads": {
                            str(number): {
                                "name": "Sin asignar",
                                "icon": "",
                                "action": {"type": "none"},
                            }
                            for number in range(1, 17)
                        },
                        "knobs": {
                            str(number): {"type":"none","source":"","curve":"obs","invert":False,"minimum_db":-60.0,"maximum_db":0.0}
                            for number in range(1,9)
                        },
                    },
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )


    def rename(self, old_name: str, new_name: str) -> str:
        old_name = str(old_name or "").strip()
        new_name = str(new_name or "").strip()
        if not old_name or not new_name:
            raise ValueError("El nombre del perfil no puede estar vacío.")
        old_path = self.folder / f"{old_name}.json"
        new_path = self.folder / f"{new_name}.json"
        if old_name.lower() != new_name.lower() and new_path.exists():
            raise FileExistsError(f"Ya existe un perfil llamado «{new_name}».")
        if not old_path.exists():
            self.create(old_name)
        data = json.loads(old_path.read_text(encoding="utf-8"))
        data["name"] = new_name
        # Escribir primero el destino para evitar perder datos ante un fallo.
        new_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        if old_path != new_path and old_path.exists():
            old_path.unlink()
        return new_name

    def delete(self, name: str) -> None:
        name = str(name or "").strip()
        if not name:
            raise ValueError("El nombre del perfil no puede estar vacío.")
        path = self.folder / f"{name}.json"
        if path.exists():
            path.unlink()

    def load(self, name: str) -> dict[str, Any]:
        self.create(name)
        path = self.folder / f"{name}.json"
        data=json.loads(path.read_text(encoding="utf-8"))
        data.setdefault("icon", "")
        data.setdefault("pads",{})
        knobs=data.setdefault("knobs",{})
        for number in range(1,9):
            knobs.setdefault(str(number),{"type":"none","source":"","curve":"obs","invert":False,"minimum_db":-60.0,"maximum_db":0.0})
        return data

    def save(self, name: str, data: dict[str, Any]) -> None:
        path = self.folder / f"{name}.json"
        path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
