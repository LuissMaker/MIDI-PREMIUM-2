from __future__ import annotations

import base64
import hashlib
import json
import logging
import threading
import uuid
from typing import Any

import websocket
from PySide6.QtCore import QObject, QTimer, Signal


class ObsError(RuntimeError):
    pass


class ObsEngine(QObject):
    connected = Signal(dict)
    disconnected = Signal(str)
    scenes_changed = Signal(list)
    inputs_changed = Signal(list)
    scene_items_changed = Signal(str, list)
    error_occurred = Signal(str)

    def __init__(
        self,
        logger: logging.Logger,
        reconnect_interval_ms: int = 5000,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.logger = logger
        self.host = "localhost"
        self.port = 4455
        self.password = ""
        self.auto_reconnect = True

        self._socket = None
        self._lock = threading.RLock()
        self._manual_disconnect = False
        self._connection_info: dict[str, Any] = {}

        self._timer = QTimer(self)
        self._timer.setInterval(max(2000, int(reconnect_interval_ms)))
        self._timer.timeout.connect(self._auto_reconnect_tick)
        self._timer.start()

    @property
    def is_connected(self) -> bool:
        with self._lock:
            return self._socket is not None

    def configure(
        self,
        host: str,
        port: int,
        password: str,
        auto_reconnect: bool = True,
    ) -> None:
        self.host = host.strip() or "localhost"
        self.port = max(1, min(65535, int(port)))
        self.password = password
        self.auto_reconnect = bool(auto_reconnect)

    def connect_async(self) -> None:
        self._manual_disconnect = False
        threading.Thread(
            target=self._connect_worker,
            daemon=True,
            name="ObsConnectWorker",
        ).start()

    def refresh_scenes_async(self) -> None:
        threading.Thread(
            target=self._scenes_worker,
            daemon=True,
            name="ObsScenesWorker",
        ).start()

    def refresh_inputs_async(self) -> None:
        threading.Thread(
            target=self._inputs_worker,
            daemon=True,
            name="ObsInputsWorker",
        ).start()

    def refresh_scene_items_async(self, scene_name: str) -> None:
        threading.Thread(
            target=self._scene_items_worker,
            args=(scene_name,),
            daemon=True,
            name="ObsSceneItemsWorker",
        ).start()

    def disconnect(
        self,
        reason: str = "OBS desconectado por el usuario.",
    ) -> None:
        self._manual_disconnect = True
        self._close_socket()
        self.disconnected.emit(reason)

    def shutdown(self) -> None:
        self._timer.stop()
        self._manual_disconnect = True
        self._close_socket()

    def set_scene(self, scene_name: str) -> None:
        scene_name = scene_name.strip()
        if not scene_name:
            raise ObsError("Selecciona una escena de OBS.")
        self._request(
            "SetCurrentProgramScene",
            {"sceneName": scene_name},
        )

    def get_scenes(self) -> list[str]:
        data = self._request("GetSceneList")
        return [
            str(item.get("sceneName", ""))
            for item in data.get("scenes", [])
            if item.get("sceneName")
        ]

    def get_inputs(self) -> list[str]:
        data = self._request("GetInputList")
        return [
            str(item.get("inputName", ""))
            for item in data.get("inputs", [])
            if item.get("inputName")
        ]

    def set_input_volume_db(
        self,
        input_name: str,
        volume_db: float,
    ) -> None:
        input_name = input_name.strip()
        if not input_name:
            raise ObsError("Selecciona una fuente de audio de OBS.")
        self._request(
            "SetInputVolume",
            {
                "inputName": input_name,
                "inputVolumeDb": float(volume_db),
            },
        )

    def set_input_muted(
        self,
        input_name: str,
        muted: bool,
    ) -> None:
        input_name = input_name.strip()
        if not input_name:
            raise ObsError("Selecciona una fuente de audio de OBS.")
        self._request(
            "SetInputMute",
            {
                "inputName": input_name,
                "inputMuted": bool(muted),
            },
        )

    def toggle_input_mute(self, input_name: str) -> None:
        input_name = input_name.strip()
        if not input_name:
            raise ObsError("Selecciona una fuente de audio de OBS.")
        self._request(
            "ToggleInputMute",
            {"inputName": input_name},
        )

    def get_scene_items(
        self,
        scene_name: str,
    ) -> list[dict[str, Any]]:
        scene_name = scene_name.strip()
        if not scene_name:
            return []

        data = self._request(
            "GetSceneItemList",
            {"sceneName": scene_name},
        )
        items: list[dict[str, Any]] = []
        for item in data.get("sceneItems", []):
            source_name = str(item.get("sourceName", "")).strip()
            item_id = item.get("sceneItemId")
            if source_name and item_id is not None:
                items.append({
                    "sourceName": source_name,
                    "sceneItemId": int(item_id),
                    "sceneItemEnabled": bool(item.get("sceneItemEnabled", True)),
                    "isGroup": bool(item.get("isGroup", False)),
                })

            if bool(item.get("isGroup", False)) and source_name:
                try:
                    group_data = self._request(
                        "GetGroupSceneItemList",
                        {"sceneName": source_name},
                    )
                    for child in group_data.get("sceneItems", []):
                        child_name = str(child.get("sourceName", "")).strip()
                        child_id = child.get("sceneItemId")
                        if child_name and child_id is not None:
                            items.append({
                                "sourceName": f"{source_name} / {child_name}",
                                "rawSourceName": child_name,
                                "groupName": source_name,
                                "sceneItemId": int(child_id),
                                "sceneItemEnabled": bool(child.get("sceneItemEnabled", True)),
                            })
                except Exception:
                    self.logger.exception("Could not list OBS group: %s", source_name)
        return items

    def set_scene_item_enabled(
        self,
        scene_name: str,
        source_name: str,
        enabled: bool,
    ) -> None:
        item = self._find_scene_item(scene_name, source_name)
        self._request(
            "SetSceneItemEnabled",
            {
                "sceneName": str(item.get("groupName", scene_name)),
                "sceneItemId": int(item["sceneItemId"]),
                "sceneItemEnabled": bool(enabled),
            },
        )

    def toggle_scene_item(
        self,
        scene_name: str,
        source_name: str,
    ) -> None:
        item = self._find_scene_item(scene_name, source_name)
        self._request(
            "SetSceneItemEnabled",
            {
                "sceneName": str(item.get("groupName", scene_name)),
                "sceneItemId": int(item["sceneItemId"]),
                "sceneItemEnabled": not bool(
                    item.get("sceneItemEnabled", True)
                ),
            },
        )

    def _find_scene_item(
        self,
        scene_name: str,
        source_name: str,
    ) -> dict[str, Any]:
        scene_name = scene_name.strip()
        source_name = source_name.strip()
        if not scene_name or not source_name:
            raise ObsError("Selecciona una escena y una fuente.")

        for item in self.get_scene_items(scene_name):
            if item.get("sourceName") == source_name:
                return item

        raise ObsError(
            f"No se encontró «{source_name}» en «{scene_name}»."
        )

    def _connect_worker(self) -> None:
        try:
            info = self._connect_sync()
            scenes = self.get_scenes()
            inputs = self.get_inputs()
        except Exception as exc:
            message = str(exc) or exc.__class__.__name__
            self.logger.exception("OBS connection failed: %s", message)
            self._close_socket()
            self.error_occurred.emit(message)
            return

        self.connected.emit(info)
        self.scenes_changed.emit(scenes)
        self.inputs_changed.emit(inputs)

    def _scenes_worker(self) -> None:
        try:
            scenes = self.get_scenes()
        except Exception as exc:
            self._emit_worker_error("OBS scenes", exc)
            return
        self.scenes_changed.emit(scenes)

    def _inputs_worker(self) -> None:
        try:
            inputs = self.get_inputs()
        except Exception as exc:
            self._emit_worker_error("OBS inputs", exc)
            return
        self.inputs_changed.emit(inputs)

    def _scene_items_worker(self, scene_name: str) -> None:
        try:
            items = self.get_scene_items(scene_name)
        except Exception as exc:
            self._emit_worker_error("OBS scene items", exc)
            return
        self.scene_items_changed.emit(scene_name, items)

    def _emit_worker_error(self, area: str, exc: Exception) -> None:
        message = str(exc) or exc.__class__.__name__
        self.logger.exception("%s failed: %s", area, message)
        self.error_occurred.emit(message)

    def _connect_sync(self) -> dict[str, Any]:
        with self._lock:
            if self._socket is not None:
                return dict(self._connection_info)

            url = f"ws://{self.host}:{self.port}"
            try:
                ws = websocket.create_connection(
                    url,
                    timeout=5,
                    enable_multithread=True,
                )
            except Exception as exc:
                raise ObsError(
                    f"No se pudo conectar con OBS en {url}: {exc}"
                ) from exc

            try:
                hello = json.loads(ws.recv())
                if hello.get("op") != 0:
                    raise ObsError(
                        "OBS no envió un saludo WebSocket válido."
                    )

                hello_data = hello.get("d", {})
                identify_data: dict[str, Any] = {
                    "rpcVersion": 1,
                    "eventSubscriptions": 0,
                }

                authentication = hello_data.get("authentication")
                if authentication:
                    if not self.password:
                        raise ObsError(
                            "OBS requiere contraseña y está vacía."
                        )
                    identify_data["authentication"] = self._authentication(
                        self.password,
                        str(authentication.get("salt", "")),
                        str(authentication.get("challenge", "")),
                    )

                ws.send(json.dumps({"op": 1, "d": identify_data}))
                identified = json.loads(ws.recv())
                if identified.get("op") != 2:
                    raise ObsError(
                        "OBS rechazó la identificación. Revisa la contraseña."
                    )

                negotiated = identified.get("d", {})
                self._socket = ws
                self._connection_info = {
                    "host": self.host,
                    "port": self.port,
                    "rpcVersion": negotiated.get(
                        "negotiatedRpcVersion",
                        1,
                    ),
                    "obsWebSocketVersion": hello_data.get(
                        "obsWebSocketVersion",
                        "",
                    ),
                }
                return dict(self._connection_info)
            except Exception:
                try:
                    ws.close()
                except Exception:
                    pass
                raise

    def _request(
        self,
        request_type: str,
        request_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            if self._socket is None:
                self._connect_sync()

            request_id = str(uuid.uuid4())
            self._socket.send(
                json.dumps(
                    {
                        "op": 6,
                        "d": {
                            "requestType": request_type,
                            "requestId": request_id,
                            "requestData": request_data or {},
                        },
                    }
                )
            )

            try:
                response = json.loads(self._socket.recv())
            except Exception as exc:
                self._close_socket()
                raise ObsError(
                    f"OBS cerró la conexión antes de responder: {exc}"
                ) from exc

            if response.get("op") != 7:
                raise ObsError("OBS devolvió una respuesta inesperada.")

            data = response.get("d", {})
            status = data.get("requestStatus", {})
            if not status.get("result", False):
                comment = status.get("comment") or "Solicitud rechazada."
                code = status.get("code", "")
                raise ObsError(f"OBS: {comment} (código {code})")

            return dict(data.get("responseData") or {})

    def _close_socket(self) -> None:
        with self._lock:
            ws = self._socket
            self._socket = None
            self._connection_info = {}

        if ws is not None:
            try:
                ws.close()
            except Exception:
                self.logger.exception("Error cerrando OBS WebSocket.")

    def _auto_reconnect_tick(self) -> None:
        if (
            not self.auto_reconnect
            or self._manual_disconnect
            or self.is_connected
        ):
            return
        self.connect_async()

    @staticmethod
    def _authentication(
        password: str,
        salt: str,
        challenge: str,
    ) -> str:
        secret = base64.b64encode(
            hashlib.sha256(
                (password + salt).encode("utf-8")
            ).digest()
        ).decode("ascii")

        return base64.b64encode(
            hashlib.sha256(
                (secret + challenge).encode("utf-8")
            ).digest()
        ).decode("ascii")
