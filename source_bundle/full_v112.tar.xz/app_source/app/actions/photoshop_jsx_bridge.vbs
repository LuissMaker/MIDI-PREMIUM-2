Option Explicit

Dim jsxPath, openIfClosed, app, startedAt, errText
If WScript.Arguments.Count < 2 Then
    WScript.Echo "ERROR: argumentos incompletos."
    WScript.Quit 2
End If

jsxPath = WScript.Arguments(0)
openIfClosed = (WScript.Arguments(1) = "1")
Set app = Nothing

On Error Resume Next
Set app = GetObject(, "Photoshop.Application")
On Error GoTo 0

If app Is Nothing Then
    If Not openIfClosed Then
        WScript.Echo "ERROR: Photoshop no está abierto."
        WScript.Quit 3
    End If

    On Error Resume Next
    Set app = CreateObject("Photoshop.Application")
    errText = Err.Description
    Err.Clear
    On Error GoTo 0

    If app Is Nothing Then
        WScript.Echo "ERROR: no se pudo crear Photoshop.Application. " & errText
        WScript.Quit 4
    End If
End If

On Error Resume Next
app.Visible = True
Err.Clear
app.DoJavaScriptFile jsxPath
If Err.Number <> 0 Then
    errText = "0x" & Hex(Err.Number) & " - " & Err.Description
    Err.Clear
    On Error GoTo 0
    WScript.Echo "ERROR: DoJavaScriptFile falló. " & errText
    WScript.Quit 5
End If
On Error GoTo 0

WScript.Echo "OK: JSX ejecutado."
WScript.Quit 0
