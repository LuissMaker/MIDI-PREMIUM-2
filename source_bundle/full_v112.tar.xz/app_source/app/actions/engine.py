from __future__ import annotations

import logging
import os
import subprocess
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Callable

from pynput.keyboard import Controller, Key

from app.actions.photoshop_psd import insert_psd_element, insert_psd_elements, insert_psd_all, PhotoshopPsdError


class ActionError(RuntimeError):
    pass


class ActionEngine:
    """Executes user actions outside the UI thread."""

    _SPECIAL_KEYS = {
        "ctrl": Key.ctrl,
        "ctrl_l": Key.ctrl_l,
        "ctrl_r": Key.ctrl_r,
        "alt": Key.alt,
        "alt_l": Key.alt_l,
        "alt_r": Key.alt_r,
        "shift": Key.shift,
        "shift_l": Key.shift_l,
        "shift_r": Key.shift_r,
        "win": Key.cmd,
        "cmd": Key.cmd,
        "enter": Key.enter,
        "tab": Key.tab,
        "esc": Key.esc,
        "escape": Key.esc,
        "space": Key.space,
        "backspace": Key.backspace,
        "delete": Key.delete,
        "insert": Key.insert,
        "home": Key.home,
        "end": Key.end,
        "page_up": Key.page_up,
        "page_down": Key.page_down,
        "up": Key.up,
        "down": Key.down,
        "left": Key.left,
        "right": Key.right,
        **{f"f{i}": getattr(Key, f"f{i}") for i in range(1, 21)},
    }

    def __init__(self, logger: logging.Logger, obs_engine=None) -> None:
        self.logger = logger
        self.obs_engine = obs_engine
        self.keyboard = Controller()

    def execute_async(
        self,
        action: dict[str, Any],
        on_success: Callable[[], None] | None = None,
        on_error: Callable[[str], None] | None = None,
    ) -> None:
        def worker() -> None:
            try:
                self.execute(action)
            except Exception as exc:
                message = str(exc) or exc.__class__.__name__
                self.logger.exception("Action failed: %s", message)
                if on_error:
                    on_error(message)
                return

            if on_success:
                on_success()

        threading.Thread(
            target=worker,
            daemon=True,
            name="ActionEngineWorker",
        ).start()

    def execute(self, action: dict[str, Any]) -> None:
        action_type = str(action.get("type", "none"))

        if action_type == "none":
            return
        if action_type == "hotkey":
            self._execute_hotkey(list(action.get("keys", [])))
            return
        if action_type == "text":
            self._execute_text(str(action.get("text", "")))
            return
        if action_type == "wait":
            time.sleep(max(0.0, min(60.0, float(action.get("seconds", 0.5)))))
            return
        if action_type == "macro":
            steps = list(action.get("steps", []))
            if not steps:
                raise ActionError("La macro no contiene pasos.")
            for index, step in enumerate(steps, start=1):
                if not isinstance(step, dict):
                    raise ActionError(f"Paso {index} de la macro no es válido.")
                self.execute(step)
            return
        if action_type == "file":
            self._execute_file(str(action.get("path", "")))
            return
        if action_type == "url":
            self._execute_url(str(action.get("url", "")))
            return
        if action_type == "photoshop_jsx":
            self._execute_photoshop_jsx(
                str(action.get("jsx_path", "")),
                str(action.get("photoshop_path", "")),
                bool(action.get("open_if_closed", True)),
            )
            return
        if action_type == "photoshop_psd_element":
            try:
                insert_psd_element(
                    str(action.get("psd_path", "")),
                    list(action.get("element_path", []) or []),
                    str(action.get("photoshop_path", "")),
                    bool(action.get("open_if_closed", True)),
                )
            except PhotoshopPsdError as exc:
                raise ActionError(str(exc)) from exc
            return
        if action_type == "photoshop_psd_elements":
            try:
                insert_psd_elements(
                    str(action.get("psd_path", "")),
                    list(action.get("element_paths", []) or []),
                    str(action.get("photoshop_path", "")),
                    bool(action.get("open_if_closed", True)),
                )
            except PhotoshopPsdError as exc:
                raise ActionError(str(exc)) from exc
            return
        if action_type == "photoshop_psd_all":
            try:
                insert_psd_all(
                    str(action.get("psd_path", "")),
                    str(action.get("photoshop_path", "")),
                    bool(action.get("open_if_closed", True)),
                    bool(action.get("visible_only", False)),
                )
            except PhotoshopPsdError as exc:
                raise ActionError(str(exc)) from exc
            return
        if action_type == "obs_scene":
            self._require_obs()
            self.obs_engine.set_scene(str(action.get("scene", "")))
            return
        if action_type == "obs_mute":
            self._require_obs()
            self.obs_engine.set_input_muted(
                str(action.get("source", "")),
                True,
            )
            return
        if action_type == "obs_unmute":
            self._require_obs()
            self.obs_engine.set_input_muted(
                str(action.get("source", "")),
                False,
            )
            return
        if action_type == "obs_toggle_mute":
            self._require_obs()
            self.obs_engine.toggle_input_mute(
                str(action.get("source", ""))
            )
            return
        if action_type == "obs_show_source":
            self._require_obs()
            if bool(action.get("toggle", False)):
                self.obs_engine.toggle_scene_item(
                    str(action.get("scene", "")),
                    str(action.get("source", "")),
                )
            else:
                self.obs_engine.set_scene_item_enabled(
                    str(action.get("scene", "")),
                    str(action.get("source", "")),
                    True,
                )
            return
        if action_type == "obs_hide_source":
            self._require_obs()
            if bool(action.get("toggle", False)):
                self.obs_engine.toggle_scene_item(
                    str(action.get("scene", "")),
                    str(action.get("source", "")),
                )
            else:
                self.obs_engine.set_scene_item_enabled(
                    str(action.get("scene", "")),
                    str(action.get("source", "")),
                    False,
                )
            return
        if action_type == "obs_toggle_source":
            self._require_obs()
            self.obs_engine.toggle_scene_item(
                str(action.get("scene", "")),
                str(action.get("source", "")),
            )
            return

        raise ActionError(f"Tipo de acción no compatible: {action_type}")

    def _require_obs(self) -> None:
        if self.obs_engine is None:
            raise ActionError("El módulo OBS no está disponible.")

    def _execute_hotkey(self, keys: list[str]) -> None:
        cleaned = [str(key).strip().lower() for key in keys if str(key).strip()]
        if not cleaned:
            raise ActionError("El atajo no contiene teclas.")

        resolved = [self._resolve_key(key) for key in cleaned]
        pressed = []

        try:
            for key in resolved:
                self.keyboard.press(key)
                pressed.append(key)
            for key in reversed(resolved):
                self.keyboard.release(key)
        finally:
            for key in reversed(pressed):
                try:
                    self.keyboard.release(key)
                except Exception:
                    pass

        self.logger.info("Hotkey executed: %s", " + ".join(cleaned))

    def _resolve_key(self, key: str):
        if key in self._SPECIAL_KEYS:
            return self._SPECIAL_KEYS[key]
        if len(key) == 1:
            return key
        raise ActionError(f"Tecla no compatible: {key}")


    def _execute_text(self, text: str) -> None:
        if not text:
            raise ActionError("El texto está vacío.")
        self.keyboard.type(text)
        self.logger.info("Text typed: %d chars", len(text))

    def _execute_file(self, raw_path: str) -> None:
        raw_path = raw_path.strip().strip('"')
        if not raw_path:
            raise ActionError("No se seleccionó ningún archivo o programa.")

        path = Path(raw_path).expanduser()
        if not path.exists():
            raise ActionError(f"El archivo no existe:\n{path}")

        try:
            os.startfile(str(path))
        except AttributeError:
            subprocess.Popen([str(path)])
        except OSError as exc:
            raise ActionError(f"No se pudo abrir el archivo:\n{exc}") from exc

        self.logger.info("File opened: %s", path)


    def _execute_photoshop_jsx(
        self,
        raw_jsx_path: str,
        raw_photoshop_path: str = "",
        open_if_closed: bool = True,
    ) -> None:
        jsx_path = Path(raw_jsx_path.strip().strip('"')).expanduser()
        if not raw_jsx_path.strip():
            raise ActionError("No se seleccionó ningún archivo JSX.")
        if not jsx_path.exists() or jsx_path.suffix.lower() not in {".jsx", ".js"}:
            raise ActionError(f"El script JSX no existe o no es válido:\n{jsx_path}")

        photoshop_path = raw_photoshop_path.strip().strip('"')
        ps_path = Path(photoshop_path).expanduser() if photoshop_path else None
        if ps_path is not None and not ps_path.exists():
            raise ActionError(f"Photoshop no existe en la ruta indicada:\n{ps_path}")

        # Photoshop 2020 expone automatización COM. VBScript resulta más fiable
        # que PowerShell para invocar DoJavaScriptFile en versiones antiguas.
        if ps_path is not None and open_if_closed:
            try:
                subprocess.Popen([str(ps_path)], creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
            except OSError as exc:
                raise ActionError(f"No se pudo abrir Photoshop:\n{exc}") from exc

        bridge_path = Path(__file__).with_name("photoshop_jsx_bridge.vbs")
        if not bridge_path.exists():
            raise ActionError(f"Falta el puente de Photoshop:\n{bridge_path}")

        args = [
            "cscript.exe",
            "//Nologo",
            str(bridge_path),
            str(jsx_path.resolve()),
            "1" if open_if_closed else "0",
        ]
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=70,
                creationflags=creationflags,
            )
        except subprocess.TimeoutExpired as exc:
            raise ActionError("Photoshop no respondió al intentar ejecutar el JSX.") from exc

        output = (result.stdout or "").strip()
        error = (result.stderr or "").strip()
        if result.returncode != 0:
            detail = error or output or "Error desconocido del puente COM."
            raise ActionError(f"No se pudo ejecutar el JSX en Photoshop:\n{detail}")

        if not output.startswith("OK"):
            raise ActionError(f"Photoshop no confirmó la ejecución del JSX:\n{output or 'Sin respuesta'}")

        self.logger.info("Photoshop JSX executed: %s", jsx_path)

    def _execute_url(self, url: str) -> None:
        url = url.strip()
        if not url:
            raise ActionError("La URL está vacía.")

        if "://" not in url:
            url = "https://" + url

        if not webbrowser.open(url, new=2):
            raise ActionError("Windows no pudo abrir la URL.")

        self.logger.info("URL opened: %s", url)
