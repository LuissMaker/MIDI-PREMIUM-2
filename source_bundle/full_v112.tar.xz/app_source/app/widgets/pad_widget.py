from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout

PAD_ICON_DIR = Path(__file__).resolve().parents[2] / "assets" / "pad_icons"


class PadWidget(QFrame):
    clicked = Signal(int)
    context_requested = Signal(int)

    def __init__(self, pad_number: int, title: str = "Sin asignar", subtitle: str = "BANK A", parent=None) -> None:
        super().__init__(parent)
        self.pad_number = pad_number
        self._selected = False
        self._active = False
        self._icon_name = ""

        self.setMinimumSize(112, 92)
        self.setMaximumSize(124, 98)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 5, 8, 6)
        layout.setSpacing(1)

        self.number_label = QLabel(f"{pad_number:02d}")
        self.number_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.number_label.setStyleSheet("color:#AEB7C8; font-size:8pt;")

        self.icon_label = QLabel("●")
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon_label.setFixedHeight(24)
        self.icon_label.setStyleSheet("color:#8792A6; font-size:15pt;")

        self.title_label = QLabel(title)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet("font-weight:700;")

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.subtitle_label.setStyleSheet("color:#8792A6; font-size:8pt;")

        layout.addWidget(self.number_label)
        layout.addStretch()
        layout.addWidget(self.icon_label)
        layout.addStretch()
        layout.addWidget(self.title_label)
        layout.addWidget(self.subtitle_label)
        self.subtitle_label.setVisible(False)
        self._apply_style()

    def set_title(self, title: str) -> None:
        self.title_label.setText(title)

    def set_icon(self, icon_name: str) -> None:
        self._icon_name = str(icon_name or "")
        path = PAD_ICON_DIR / self._icon_name if self._icon_name else None
        if path and path.exists():
            pix = QIcon(str(path)).pixmap(QSize(22, 22))
            self.icon_label.setPixmap(pix)
            self.icon_label.setText("")
        else:
            self.icon_label.clear()
            self.icon_label.setText("●")
        self._refresh_icon_state()

    def set_selected(self, selected: bool) -> None:
        self._selected = selected
        self._apply_style()
        self._refresh_icon_state()

    def set_activity(self, active: bool) -> None:
        self._active = active
        self._apply_style()
        self._refresh_icon_state()

    def _refresh_icon_state(self) -> None:
        if not self._icon_name:
            color = "#63D98A" if self._active else ("#8AB8FF" if self._selected else "#8792A6")
            self.icon_label.setStyleSheet(f"color:{color}; font-size:15pt;")

    def _apply_style(self) -> None:
        if self._active:
            border, background = "#63D98A", "#1B2A24"
        elif self._selected:
            border, background = "#3388FF", "#1A2433"
        else:
            border, background = "#323A47", "#20252D"
        self.setStyleSheet(f"""
            QFrame {{ background-color: {background}; border: 1px solid {border}; border-radius: 11px; }}
            QLabel {{ border: none; background: transparent; }}
        """)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.pad_number); event.accept(); return
        if event.button() == Qt.MouseButton.RightButton:
            self.context_requested.emit(self.pad_number); event.accept(); return
        super().mousePressEvent(event)
