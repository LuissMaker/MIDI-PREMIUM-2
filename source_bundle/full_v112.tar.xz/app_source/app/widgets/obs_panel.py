from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QToolButton,
    QVBoxLayout,
)


class ObsPanel(QFrame):
    connect_requested = Signal(dict)
    disconnect_requested = Signal()
    refresh_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("MonitorPanel")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("OBS WebSocket")
        title.setObjectName("SectionTitle")

        self.status = QLabel("● Sin conectar")
        self.status.setStyleSheet("color:#E7B955; font-weight:700;")

        self.details_button = QToolButton()
        self.details_button.setText("Mostrar ajustes")
        self.details_button.setCheckable(True)
        self.details_button.toggled.connect(self._toggle_details)

        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.status)
        header.addWidget(self.details_button)

        self.details = QFrame()
        details_layout = QGridLayout(self.details)
        details_layout.setContentsMargins(0, 4, 0, 0)

        self.host_input = QLineEdit("localhost")
        self.port_input = QSpinBox()
        self.port_input.setRange(1, 65535)
        self.port_input.setValue(4455)
        self.port_input.setMinimumWidth(92)

        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.eye_button = QPushButton("👁")
        self.eye_button.setFixedWidth(42)
        self.eye_button.setCheckable(True)
        self.eye_button.toggled.connect(self._show_password)

        self.auto_reconnect = QCheckBox("Reconectar automáticamente")
        self.auto_reconnect.setChecked(True)

        details_layout.addWidget(QLabel("Servidor"), 0, 0)
        details_layout.addWidget(self.host_input, 0, 1)
        details_layout.addWidget(QLabel("Puerto"), 0, 2)
        details_layout.addWidget(self.port_input, 0, 3)
        details_layout.addWidget(QLabel("Contraseña"), 1, 0)
        details_layout.addWidget(self.password_input, 1, 1, 1, 2)
        details_layout.addWidget(self.eye_button, 1, 3)
        details_layout.addWidget(self.auto_reconnect, 2, 0, 1, 4)

        buttons = QHBoxLayout()
        self.connect_button = QPushButton("Probar conexión")
        self.disconnect_button = QPushButton("Desconectar")
        self.refresh_button = QPushButton("Recargar escenas")
        self.disconnect_button.setEnabled(False)
        self.refresh_button.setEnabled(False)

        self.connect_button.clicked.connect(
            lambda: self.connect_requested.emit(self.get_settings())
        )
        self.disconnect_button.clicked.connect(
            self.disconnect_requested.emit
        )
        self.refresh_button.clicked.connect(
            self.refresh_requested.emit
        )

        buttons.addWidget(self.connect_button)
        buttons.addWidget(self.disconnect_button)
        buttons.addStretch()
        buttons.addWidget(self.refresh_button)

        self.info = QLabel(
            "En OBS: Herramientas → Configuración del servidor WebSocket."
        )
        self.info.setObjectName("Muted")
        self.info.setWordWrap(True)

        layout.addLayout(header)
        layout.addWidget(self.details)
        layout.addLayout(buttons)
        layout.addWidget(self.info)

        self.details.setVisible(False)

    def get_settings(self) -> dict:
        return {
            "host": self.host_input.text().strip() or "localhost",
            "port": self.port_input.value(),
            "password": self.password_input.text(),
            "auto_reconnect": self.auto_reconnect.isChecked(),
        }

    def set_settings(self, settings: dict) -> None:
        self.host_input.setText(str(settings.get("host", "localhost")))
        self.port_input.setValue(int(settings.get("port", 4455)))
        self.password_input.setText(str(settings.get("password", "")))
        self.auto_reconnect.setChecked(
            bool(settings.get("auto_reconnect", True))
        )

    def set_connected(self, info: dict) -> None:
        self.status.setText("● OBS conectado")
        self.status.setStyleSheet("color:#63D98A; font-weight:700;")
        self.connect_button.setText("Probar conexión")
        self.disconnect_button.setEnabled(True)
        self.refresh_button.setEnabled(True)

        ws_version = info.get("obsWebSocketVersion", "")
        suffix = f" · WebSocket {ws_version}" if ws_version else ""
        self.info.setText(
            f"Conectado a {info.get('host')}:{info.get('port')}{suffix}"
        )

    def set_disconnected(self, message: str) -> None:
        self.status.setText("● Sin conectar")
        self.status.setStyleSheet("color:#E7B955; font-weight:700;")
        self.disconnect_button.setEnabled(False)
        self.refresh_button.setEnabled(False)
        self.info.setText(message)

    def set_error(self, message: str) -> None:
        self.status.setText("● Error de conexión")
        self.status.setStyleSheet("color:#F06A6A; font-weight:700;")
        self.disconnect_button.setEnabled(False)
        self.refresh_button.setEnabled(False)
        self.info.setText(message)

    def _toggle_details(self, visible: bool) -> None:
        self.details.setVisible(visible)
        self.details_button.setText(
            "Ocultar ajustes" if visible else "Mostrar ajustes"
        )

    def _show_password(self, visible: bool) -> None:
        self.password_input.setEchoMode(
            QLineEdit.EchoMode.Normal
            if visible
            else QLineEdit.EchoMode.Password
        )
