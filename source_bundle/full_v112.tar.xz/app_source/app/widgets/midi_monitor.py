from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
)

from app.midi.event import MidiEvent


class MidiMonitor(QFrame):
    refresh_requested = Signal()
    connect_requested = Signal(str)
    disconnect_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("MonitorPanel")
        self.message_count = 0

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(9)

        header = QHBoxLayout()
        title = QLabel("Monitor MIDI")
        title.setObjectName("SectionTitle")
        self.status = QLabel("● Sin conectar")
        self.status.setStyleSheet("color:#E7B955; font-weight:700;")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.status)

        row = QHBoxLayout()
        self.device_combo = QComboBox()
        self.refresh_button = QPushButton("Actualizar")
        self.connect_button = QPushButton("Conectar")
        self.disconnect_button = QPushButton("Desconectar")
        self.disconnect_button.setEnabled(False)

        self.refresh_button.clicked.connect(self.refresh_requested.emit)
        self.connect_button.clicked.connect(
            lambda: self.connect_requested.emit(self.device_combo.currentText())
        )
        self.disconnect_button.clicked.connect(self.disconnect_requested.emit)

        row.addWidget(self.device_combo, 1)
        row.addWidget(self.refresh_button)
        row.addWidget(self.connect_button)
        row.addWidget(self.disconnect_button)

        self.summary = QLabel("Sin mensajes MIDI")
        self.summary.setObjectName("Muted")

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(135)
        self.log.setMaximumBlockCount(500)

        footer = QHBoxLayout()
        self.counter = QLabel("Mensajes: 0")
        self.counter.setObjectName("Muted")
        clear = QPushButton("Limpiar")
        clear.clicked.connect(self.clear_messages)
        footer.addWidget(self.counter)
        footer.addStretch()
        footer.addWidget(clear)

        layout.addLayout(header)
        layout.addLayout(row)
        layout.addWidget(self.summary)
        layout.addWidget(self.log, 1)
        layout.addLayout(footer)

    def set_devices(self, devices: list[str], preferred: str = "") -> None:
        self.device_combo.clear()
        if not devices:
            self.device_combo.addItem("No se encontraron dispositivos MIDI")
            self.connect_button.setEnabled(False)
            return
        self.device_combo.addItems(devices)
        self.connect_button.setEnabled(True)
        if preferred in devices:
            self.device_combo.setCurrentText(preferred)

    def set_connected(self, device_name: str) -> None:
        self.status.setText("● Conectado")
        self.status.setStyleSheet("color:#63D98A; font-weight:700;")
        self.device_combo.setCurrentText(device_name)
        self.device_combo.setEnabled(False)
        self.connect_button.setEnabled(False)
        self.disconnect_button.setEnabled(True)
        self.append_system(f"Conectado a {device_name}")

    def set_disconnected(self, reason: str) -> None:
        self.status.setText("● Sin conectar")
        self.status.setStyleSheet("color:#E7B955; font-weight:700;")
        self.device_combo.setEnabled(True)
        self.connect_button.setEnabled(True)
        self.disconnect_button.setEnabled(False)
        self.append_system(reason)

    def set_error(self, message: str) -> None:
        self.status.setText("● Error")
        self.status.setStyleSheet("color:#F06A6A; font-weight:700;")
        self.append_system(message)

    def append_event(self, event: MidiEvent) -> None:
        self.message_count += 1
        self.counter.setText(f"Mensajes: {self.message_count}")
        self.summary.setText(event.summary())
        self.log.appendPlainText(
            f"[{datetime.now().strftime('%H:%M:%S')}] {event.raw_text}"
        )

    def append_system(self, message: str) -> None:
        self.log.appendPlainText(
            f"[{datetime.now().strftime('%H:%M:%S')}] — {message}"
        )

    def clear_messages(self) -> None:
        self.message_count = 0
        self.counter.setText("Mensajes: 0")
        self.summary.setText("Sin mensajes MIDI")
        self.log.clear()
