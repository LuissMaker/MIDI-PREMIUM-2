from __future__ import annotations

from copy import deepcopy
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QPushButton, QStackedWidget, QVBoxLayout, QWidget, QMessageBox,
)

from app.actions.photoshop_psd import list_psd_elements, PhotoshopPsdError


class ActionEditor(QFrame):
    action_changed = Signal()
    action_type_changed = Signal(str)
    refresh_obs_scenes_requested = Signal()
    refresh_obs_inputs_requested = Signal()
    refresh_scene_items_requested = Signal(str)

    AUDIO_TYPES = {"obs_mute", "obs_unmute", "obs_toggle_mute"}
    ITEM_TYPES = {"obs_show_source", "obs_hide_source", "obs_toggle_source"}
    KEY_OPTIONS = ([chr(c) for c in range(ord("A"), ord("Z") + 1)] +
                   [str(n) for n in range(10)] + [f"F{n}" for n in range(1, 21)] +
                   ["Enter", "Tab", "Esc", "Space", "Delete"])

    def __init__(self, parent=None, allow_macro: bool = True, global_paths: dict | None = None) -> None:
        super().__init__(parent)
        self.allow_macro = allow_macro
        self.global_paths = dict(global_paths or {})
        self._psd_element_items: list[dict] = []
        self.recording = False
        self.scene_items: dict[str, list[str]] = {}
        self.macro_steps: list[dict] = []
        layout = QVBoxLayout(self); layout.setContentsMargins(0, 0, 0, 0)
        self.action_combo = QComboBox()
        items = [
            ("Sin acción", "none"), ("Atajo de teclado", "hotkey"),
            ("Escribir texto", "text"), ("Esperar", "wait"),
            ("Ejecutar archivo o programa", "file"), ("Abrir URL", "url"),
            ("Photoshop 2020: Ejecutar JSX", "photoshop_jsx"),
            ("Photoshop: Insertar elemento PSD", "photoshop_psd_element"),
            ("Photoshop: Elegir elemento PSD", "photoshop_psd_selector"),
            ("Photoshop: Insertar PSD completo", "photoshop_psd_all"),
            ("Preset: Siguiente", "ui_profile_next"), ("Preset: Anterior", "ui_profile_prev"),
            ("Bank: A", "ui_bank_a"), ("Bank: B", "ui_bank_b"), ("Bank: Alternar A/B", "ui_bank_toggle"),
            ("OBS: Cambiar escena", "obs_scene"), ("OBS: Silenciar fuente", "obs_mute"),
            ("OBS: Activar sonido", "obs_unmute"), ("OBS: Alternar silencio", "obs_toggle_mute"),
            ("OBS: Mostrar fuente", "obs_show_source"), ("OBS: Ocultar fuente", "obs_hide_source"),
            ("OBS: Alternar visibilidad", "obs_toggle_source"),
        ]
        if allow_macro:
            items.insert(1, ("Macro · múltiples pasos", "macro"))
        else:
            # Un selector requiere UI de MIDI Premium durante la ejecución; no se ofrece dentro de macros.
            items = [item for item in items if item[1] != "photoshop_psd_selector"]
        for label, value in items: self.action_combo.addItem(label, value)

        self.stack = QStackedWidget()
        self.none_page = self._message_page("Este pad no ejecutará ninguna acción.")
        self.hotkey_page = self._hotkey_page(); self.text_page = self._text_page(); self.wait_page = self._wait_page()
        self.file_page = self._file_page(); self.url_page = self._url_page(); self.photoshop_jsx_page = self._photoshop_jsx_page()
        self.photoshop_psd_element_page = self._photoshop_psd_element_page(); self.photoshop_psd_selector_page = self._photoshop_psd_selector_page(); self.photoshop_psd_all_page = self._photoshop_psd_all_page()
        self.scene_page = self._scene_page(); self.audio_page = self._audio_page(); self.item_page = self._item_page()
        self.macro_page = self._macro_page() if allow_macro else self.none_page
        for page in (self.none_page, self.hotkey_page, self.text_page, self.wait_page, self.file_page, self.url_page,
                     self.photoshop_jsx_page, self.photoshop_psd_element_page, self.photoshop_psd_selector_page, self.photoshop_psd_all_page, self.scene_page, self.audio_page, self.item_page): self.stack.addWidget(page)
        if allow_macro: self.stack.addWidget(self.macro_page)
        self.action_combo.currentIndexChanged.connect(self._change_page)
        layout.addWidget(self.action_combo); layout.addWidget(self.stack, 1); self._change_page()

    def _message_page(self, text):
        page=QWidget(); l=QVBoxLayout(page); q=QLabel(text); q.setObjectName("Muted"); l.addWidget(q); l.addStretch(); return page
    def _hotkey_page(self):
        page=QWidget(); l=QVBoxLayout(page); row=QHBoxLayout(); self.ctrl=QCheckBox("Ctrl"); self.alt=QCheckBox("Alt"); self.shift=QCheckBox("Shift"); self.win=QCheckBox("Win")
        for w in (self.ctrl,self.alt,self.shift,self.win): row.addWidget(w); w.toggled.connect(self._update_preview)
        row.addStretch(); self.key=QComboBox(); self.key.addItems(self.KEY_OPTIONS); self.key.currentTextChanged.connect(self._update_preview)
        self.preview=QLabel("A"); self.record=QPushButton("● Grabar combinación"); self.record.clicked.connect(self._start_recording)
        l.addLayout(row); l.addWidget(self.key); l.addWidget(self.preview); l.addWidget(self.record); l.addStretch(); return page
    def _text_page(self):
        p=QWidget(); l=QVBoxLayout(p); self.text_input=QLineEdit(); self.text_input.setPlaceholderText("Texto que se escribirá automáticamente"); l.addWidget(QLabel("Texto")); l.addWidget(self.text_input); l.addStretch(); return p
    def _wait_page(self):
        p=QWidget(); l=QVBoxLayout(p); self.wait_seconds=QDoubleSpinBox(); self.wait_seconds.setRange(0.05,60.0); self.wait_seconds.setValue(0.5); self.wait_seconds.setSingleStep(0.1); self.wait_seconds.setSuffix(" s"); l.addWidget(QLabel("Duración")); l.addWidget(self.wait_seconds); l.addStretch(); return p
    def _file_page(self):
        p=QWidget(); l=QVBoxLayout(p); r=QHBoxLayout(); self.file_path=QLineEdit(); b=QPushButton("Examinar…"); b.clicked.connect(self._browse); r.addWidget(self.file_path,1); r.addWidget(b); l.addWidget(QLabel("Archivo o programa")); l.addLayout(r); l.addStretch(); return p
    def _url_page(self):
        p=QWidget(); l=QVBoxLayout(p); self.url=QLineEdit(); self.url.setPlaceholderText("https://..."); l.addWidget(QLabel("URL")); l.addWidget(self.url); l.addStretch(); return p
    def _photoshop_jsx_page(self):
        p=QWidget(); l=QVBoxLayout(p); r=QHBoxLayout(); self.jsx_path=QLineEdit(); b=QPushButton("Examinar…"); b.clicked.connect(self._browse_jsx); r.addWidget(self.jsx_path,1); r.addWidget(b); l.addWidget(QLabel("Archivo JSX")); l.addLayout(r)
        r2=QHBoxLayout(); self.photoshop_path=QLineEdit(); self.photoshop_path.setPlaceholderText(self.global_paths.get("photoshop_exe", "Ruta global de Photoshop")); b2=QPushButton("Examinar…"); b2.clicked.connect(self._browse_photoshop); r2.addWidget(self.photoshop_path,1); r2.addWidget(b2); l.addWidget(QLabel("Photoshop (opcional si hay ruta global)")); l.addLayout(r2)
        self.open_photoshop_check=QCheckBox("Abrir Photoshop si está cerrado"); self.open_photoshop_check.setChecked(True); l.addWidget(self.open_photoshop_check); l.addStretch(); return p

    def _psd_file_row(self, line_edit):
        row=QHBoxLayout(); button=QPushButton("Examinar…")
        def browse():
            p,_=QFileDialog.getOpenFileName(self,"Seleccionar biblioteca PSD/PSB","","Photoshop (*.psd *.psb);;Todos los archivos (*.*)")
            if p: line_edit.setText(p)
        button.clicked.connect(browse); row.addWidget(line_edit,1); row.addWidget(button); return row

    def _photoshop_psd_element_page(self):
        p=QWidget(); l=QVBoxLayout(p)
        self.psd_element_file=QLineEdit(); l.addWidget(QLabel("Biblioteca PSD/PSB")); l.addLayout(self._psd_file_row(self.psd_element_file))
        row=QHBoxLayout(); self.psd_element_combo=QComboBox(); self.psd_element_combo.setEditable(False); self.psd_element_combo.setMinimumContentsLength(28)
        choose=QPushButton("Seleccionar…"); choose.setToolTip("Abre una lista para elegir exactamente la capa o grupo del PSD")
        choose.clicked.connect(self._choose_psd_element)
        load=QPushButton("Cargar elementos"); load.clicked.connect(self._load_psd_elements)
        row.addWidget(self.psd_element_combo,1); row.addWidget(choose); row.addWidget(load)
        l.addWidget(QLabel("Capa o grupo a insertar")); l.addLayout(row)
        note=QLabel("Duplica únicamente la capa o grupo elegido al documento que tengas activo, conservándolo editable."); note.setObjectName("Muted"); note.setWordWrap(True); l.addWidget(note); l.addStretch(); return p

    def _photoshop_psd_selector_page(self):
        p=QWidget(); l=QVBoxLayout(p)
        self.psd_selector_file=QLineEdit(); l.addWidget(QLabel("Biblioteca PSD/PSB")); l.addLayout(self._psd_file_row(self.psd_selector_file))
        note=QLabel("Al pulsar el PAD, MIDI Premium abrirá un selector con las capas y grupos de este PSD. Solo se insertará el elemento que elijas."); note.setObjectName("Muted"); note.setWordWrap(True); l.addWidget(note); l.addStretch(); return p

    def _photoshop_psd_all_page(self):
        p=QWidget(); l=QVBoxLayout(p)
        self.psd_all_file=QLineEdit(); l.addWidget(QLabel("Biblioteca PSD/PSB")); l.addLayout(self._psd_file_row(self.psd_all_file))
        self.psd_all_visible=QCheckBox("Insertar solo capas/grupos visibles del nivel principal")
        l.addWidget(self.psd_all_visible)
        note=QLabel("Inserta de una vez todo el contenido principal del PSD en el documento activo. La estructura de cada grupo se conserva."); note.setObjectName("Muted"); note.setWordWrap(True); l.addWidget(note); l.addStretch(); return p

    def _load_psd_elements(self):
        path=self.psd_element_file.text().strip()
        if not path:
            QMessageBox.information(self,"Biblioteca PSD","Selecciona primero un archivo PSD o PSB."); return
        try:
            items=list_psd_elements(path,str(self.global_paths.get("photoshop_exe", "")),True)
        except Exception as exc:
            QMessageBox.warning(self,"No se pudieron leer los elementos",str(exc)); return
        current_data=self.psd_element_combo.currentData(); current_text=self.psd_element_combo.currentText(); self.psd_element_combo.clear()
        self._psd_element_items = list(items)
        for item in items:
            prefix="Grupo" if item.get("kind")=="group" else "Capa"
            self.psd_element_combo.addItem(f"{prefix} · {item.get('label','')}", list(item.get("path",[])))
        if current_data:
            for i in range(self.psd_element_combo.count()):
                if list(self.psd_element_combo.itemData(i) or []) == list(current_data or []):
                    self.psd_element_combo.setCurrentIndex(i); break
        elif current_text:
            idx=self.psd_element_combo.findText(current_text)
            if idx>=0: self.psd_element_combo.setCurrentIndex(idx)
        if not items: QMessageBox.information(self,"Biblioteca PSD","No se encontraron capas o grupos.")

    def _choose_psd_element(self):
        if not self._psd_element_items:
            self._load_psd_elements()
        if not self._psd_element_items:
            return
        dlg=QDialog(self); dlg.setWindowTitle("Seleccionar elemento del PSD"); dlg.resize(520,560)
        lay=QVBoxLayout(dlg); search=QLineEdit(); search.setPlaceholderText("Buscar capa o grupo…"); lay.addWidget(search)
        lst=QListWidget(); lay.addWidget(lst,1)
        for item in self._psd_element_items:
            prefix="Grupo" if item.get("kind")=="group" else "Capa"
            from PySide6.QtWidgets import QListWidgetItem
            row=QListWidgetItem(f"{prefix} · {item.get('label','')}"); row.setData(Qt.ItemDataRole.UserRole, list(item.get("path",[]))); lst.addItem(row)
        if lst.count(): lst.setCurrentRow(0)
        def filt(text):
            q=text.strip().lower()
            for i in range(lst.count()):
                it=lst.item(i); it.setHidden(bool(q) and q not in it.text().lower())
        search.textChanged.connect(filt)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Seleccionar"); buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject); lay.addWidget(buttons)
        lst.itemDoubleClicked.connect(lambda *_: dlg.accept())
        if dlg.exec()!=QDialog.DialogCode.Accepted or not lst.currentItem(): return
        chosen=list(lst.currentItem().data(Qt.ItemDataRole.UserRole) or [])
        for i in range(self.psd_element_combo.count()):
            if list(self.psd_element_combo.itemData(i) or []) == chosen:
                self.psd_element_combo.setCurrentIndex(i); break

    def _scene_page(self):
        p=QWidget(); l=QVBoxLayout(p); r=QHBoxLayout(); self.scene=QComboBox(); b=QPushButton("Recargar"); b.clicked.connect(self.refresh_obs_scenes_requested.emit); r.addWidget(self.scene,1); r.addWidget(b); l.addWidget(QLabel("Escena")); l.addLayout(r); l.addStretch(); return p
    def _audio_page(self):
        p=QWidget(); l=QVBoxLayout(p); r=QHBoxLayout(); self.audio_source=QComboBox(); b=QPushButton("Recargar"); b.clicked.connect(self.refresh_obs_inputs_requested.emit); r.addWidget(self.audio_source,1); r.addWidget(b); l.addWidget(QLabel("Fuente de audio")); l.addLayout(r); l.addStretch(); return p
    def _item_page(self):
        p=QWidget(); l=QVBoxLayout(p); sr=QHBoxLayout(); self.item_scene=QComboBox(); self.item_scene.currentTextChanged.connect(self._item_scene_changed); bs=QPushButton("Recargar escenas"); bs.clicked.connect(self.refresh_obs_scenes_requested.emit); sr.addWidget(self.item_scene,1); sr.addWidget(bs)
        ir=QHBoxLayout(); self.item_source=QComboBox(); bi=QPushButton("Recargar fuentes"); bi.clicked.connect(lambda:self.refresh_scene_items_requested.emit(self.item_scene.currentText())); ir.addWidget(self.item_source,1); ir.addWidget(bi)
        self.item_toggle_check=QCheckBox("Alternar con cada pulsación"); l.addWidget(QLabel("Escena")); l.addLayout(sr); l.addWidget(QLabel("Fuente dentro de la escena")); l.addLayout(ir); l.addWidget(self.item_toggle_check); l.addStretch(); return p
    def _macro_page(self):
        p=QWidget(); l=QVBoxLayout(p); note=QLabel("Ejecuta varios pasos en orden. Usa ‘Esperar’ entre acciones cuando una aplicación necesite tiempo."); note.setWordWrap(True); note.setObjectName("Muted"); l.addWidget(note)
        self.macro_list=QListWidget(); self.macro_list.itemDoubleClicked.connect(lambda *_: self._edit_macro_step()); l.addWidget(self.macro_list,1)
        r=QHBoxLayout();
        for text,fn in [("+ Añadir",self._add_macro_step),("Editar",self._edit_macro_step),("↑",lambda:self._move_macro(-1)),("↓",lambda:self._move_macro(1)),("Eliminar",self._delete_macro_step)]:
            b=QPushButton(text); b.clicked.connect(fn); r.addWidget(b)
        l.addLayout(r); return p

    def _change_page(self,*_):
        t=str(self.action_combo.currentData()); page={"macro":self.macro_page,"hotkey":self.hotkey_page,"text":self.text_page,"wait":self.wait_page,"file":self.file_page,"url":self.url_page,"photoshop_jsx":self.photoshop_jsx_page,"photoshop_psd_element":self.photoshop_psd_element_page,"photoshop_psd_selector":self.photoshop_psd_selector_page,"photoshop_psd_all":self.photoshop_psd_all_page,"obs_scene":self.scene_page}.get(t)
        if t in self.AUDIO_TYPES: page=self.audio_page
        elif t in self.ITEM_TYPES: page=self.item_page
        self.stack.setCurrentWidget(page or self.none_page)
        self.action_type_changed.emit(t)
        self.action_changed.emit()
    def _summary(self,a):
        t=a.get("type","none")
        if t=="hotkey": return "Teclas · "+" + ".join(str(k).upper() for k in a.get("keys",[]))
        if t=="text": return "Texto · "+str(a.get("text",""))[:45]
        if t=="wait": return f"Esperar · {a.get('seconds',0.5)} s"
        if t=="file": return "Abrir · "+str(a.get("path",""))
        if t=="url": return "URL · "+str(a.get("url",""))
        if t=="photoshop_jsx": return "Photoshop JSX · "+str(a.get("jsx_path",""))
        if t=="photoshop_psd_element": return "Photoshop PSD · "+" / ".join(a.get("element_path",[]) or [])
        if t=="photoshop_psd_selector": return "Photoshop PSD · Selector"
        if t=="photoshop_psd_all": return "Photoshop PSD · Completo"
        if t=="obs_scene": return "OBS escena · "+str(a.get("scene",""))
        if t=="ui_profile_next": return "Preset · Siguiente"
        if t=="ui_profile_prev": return "Preset · Anterior"
        if t=="ui_bank_a": return "Bank · A"
        if t=="ui_bank_b": return "Bank · B"
        if t=="ui_bank_toggle": return "Bank · Alternar"
        if t.startswith("obs_"): return "OBS · "+str(a.get("source",a.get("scene","")))
        return "Sin acción"
    def _refresh_macro(self):
        self.macro_list.clear()
        for i,a in enumerate(self.macro_steps,1): self.macro_list.addItem(f"{i:02d}  {self._summary(a)}")
    def _step_dialog(self, action=None):
        d=QDialog(self); d.setWindowTitle("Paso de macro"); d.resize(620,470); l=QVBoxLayout(d); ed=ActionEditor(d,allow_macro=False,global_paths=self.global_paths); l.addWidget(ed,1); bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel); bb.accepted.connect(d.accept); bb.rejected.connect(d.reject); l.addWidget(bb); ed.set_action(action or {"type":"none"})
        return ed.get_action() if d.exec()==QDialog.DialogCode.Accepted else None
    def _add_macro_step(self):
        a=self._step_dialog();
        if a and a.get("type")!="none": self.macro_steps.append(a); self._refresh_macro()
    def _edit_macro_step(self):
        row=self.macro_list.currentRow();
        if row<0 or row>=len(self.macro_steps): return
        a=self._step_dialog(self.macro_steps[row]);
        if a: self.macro_steps[row]=a; self._refresh_macro(); self.macro_list.setCurrentRow(row)
    def _delete_macro_step(self):
        row=self.macro_list.currentRow();
        if 0<=row<len(self.macro_steps): self.macro_steps.pop(row); self._refresh_macro()
    def _move_macro(self,delta):
        row=self.macro_list.currentRow(); new=row+delta
        if 0<=row<len(self.macro_steps) and 0<=new<len(self.macro_steps): self.macro_steps[row],self.macro_steps[new]=self.macro_steps[new],self.macro_steps[row]; self._refresh_macro(); self.macro_list.setCurrentRow(new)

    def set_obs_scenes(self,scenes):
        for c in (self.scene,self.item_scene): cur=c.currentText(); c.clear(); c.addItems(scenes); c.setCurrentText(cur) if cur in scenes else None
    def set_obs_inputs(self,inputs):
        cur=self.audio_source.currentText(); self.audio_source.clear(); self.audio_source.addItems(inputs); self.audio_source.setCurrentText(cur) if cur in inputs else None
    def set_scene_items(self,scene,items):
        self.scene_items[scene]=[str(i.get("sourceName","")) for i in items if i.get("sourceName")]; self._fill_items(self.scene_items[scene]) if self.item_scene.currentText()==scene else None
    def _item_scene_changed(self,scene):
        names=self.scene_items.get(scene,[]); self._fill_items(names)
        if scene and not names: self.refresh_scene_items_requested.emit(scene)
    def _fill_items(self,names):
        cur=self.item_source.currentText(); self.item_source.clear(); self.item_source.addItems(names); self.item_source.setCurrentText(cur) if cur in names else None

    def get_action(self):
        t=str(self.action_combo.currentData())
        if t=="macro": return {"type":"macro","steps":deepcopy(self.macro_steps)}
        if t=="hotkey": return {"type":"hotkey","keys":self._keys()}
        if t=="text": return {"type":"text","text":self.text_input.text()}
        if t=="wait": return {"type":"wait","seconds":self.wait_seconds.value()}
        if t=="file": return {"type":"file","path":self.file_path.text().strip()}
        if t=="url": return {"type":"url","url":self.url.text().strip()}
        if t=="photoshop_jsx": return {"type":"photoshop_jsx","jsx_path":self.jsx_path.text().strip(),"photoshop_path":self.photoshop_path.text().strip() or str(self.global_paths.get("photoshop_exe", "")).strip(),"open_if_closed":self.open_photoshop_check.isChecked()}
        if t=="photoshop_psd_element":
            data=self.psd_element_combo.currentData(); path=list(data) if isinstance(data,(list,tuple)) else [x.strip() for x in self.psd_element_combo.currentText().replace("Grupo · ","").replace("Capa · ","").split(" / ") if x.strip()]
            return {"type":t,"psd_path":self.psd_element_file.text().strip(),"element_path":path,"photoshop_path":str(self.global_paths.get("photoshop_exe", "")).strip(),"open_if_closed":True}
        if t=="photoshop_psd_selector": return {"type":t,"psd_path":self.psd_selector_file.text().strip(),"photoshop_path":str(self.global_paths.get("photoshop_exe", "")).strip(),"open_if_closed":True}
        if t=="photoshop_psd_all": return {"type":t,"psd_path":self.psd_all_file.text().strip(),"visible_only":self.psd_all_visible.isChecked(),"photoshop_path":str(self.global_paths.get("photoshop_exe", "")).strip(),"open_if_closed":True}
        if t=="obs_scene": return {"type":t,"scene":self.scene.currentText()}
        if t in self.AUDIO_TYPES: return {"type":t,"source":self.audio_source.currentText()}
        if t in self.ITEM_TYPES: return {"type":t,"scene":self.item_scene.currentText(),"source":self.item_source.currentText(),"toggle":self.item_toggle_check.isChecked()}
        if t.startswith("ui_"): return {"type":t}
        return {"type":"none"}
    def set_action(self,action):
        action=action if isinstance(action,dict) else {"type":"none"}; t=str(action.get("type","none")); idx=self.action_combo.findData(t); self.action_combo.setCurrentIndex(idx if idx>=0 else 0)
        if t=="macro": self.macro_steps=deepcopy(list(action.get("steps",[]))); self._refresh_macro()
        elif t=="hotkey":
            keys=[str(k).lower() for k in action.get("keys",[])]; self.ctrl.setChecked("ctrl" in keys); self.alt.setChecked("alt" in keys); self.shift.setChecked("shift" in keys); self.win.setChecked("win" in keys); principal=next((k for k in keys if k not in {"ctrl","alt","shift","win"}),"a"); self._set_combo(self.key, principal.upper() if principal.startswith("f") else principal.title())
        elif t=="text": self.text_input.setText(str(action.get("text","")))
        elif t=="wait": self.wait_seconds.setValue(float(action.get("seconds",0.5)))
        elif t=="file": self.file_path.setText(str(action.get("path","")))
        elif t=="url": self.url.setText(str(action.get("url","")))
        elif t=="photoshop_jsx": self.jsx_path.setText(str(action.get("jsx_path",""))); self.photoshop_path.setText(str(action.get("photoshop_path",""))); self.open_photoshop_check.setChecked(bool(action.get("open_if_closed",True)))
        elif t=="photoshop_psd_element":
            self.psd_element_file.setText(str(action.get("psd_path",""))); parts=list(action.get("element_path",[]) or []); label=" / ".join(str(x) for x in parts); self.psd_element_combo.clear(); self.psd_element_combo.addItem(label, parts); self.psd_element_combo.setCurrentIndex(0); self._psd_element_items=[]
        elif t=="photoshop_psd_selector": self.psd_selector_file.setText(str(action.get("psd_path","")))
        elif t=="photoshop_psd_all": self.psd_all_file.setText(str(action.get("psd_path",""))); self.psd_all_visible.setChecked(bool(action.get("visible_only",False)))
        elif t=="obs_scene": self._set_combo(self.scene,str(action.get("scene","")))
        elif t in self.AUDIO_TYPES: self._set_combo(self.audio_source,str(action.get("source","")))
        elif t in self.ITEM_TYPES: self._set_combo(self.item_scene,str(action.get("scene",""))); self._set_combo(self.item_source,str(action.get("source",""))); self.item_toggle_check.setChecked(bool(action.get("toggle",False)))
        self._update_preview()
    def _browse(self):
        p,_=QFileDialog.getOpenFileName(self,"Seleccionar archivo","","Todos los archivos (*.*)"); self.file_path.setText(p) if p else None
    def _browse_jsx(self):
        start=str(self.global_paths.get("photoshop_scripts", ""))
        p,_=QFileDialog.getOpenFileName(self,"Seleccionar script de Photoshop",start,"Scripts de Photoshop (*.jsx *.js);;Todos los archivos (*.*)"); self.jsx_path.setText(p) if p else None
    def _browse_photoshop(self):
        p,_=QFileDialog.getOpenFileName(self,"Seleccionar Photoshop.exe","","Aplicaciones (*.exe);;Todos los archivos (*.*)"); self.photoshop_path.setText(p) if p else None
    def _keys(self):
        r=[]
        if self.ctrl.isChecked(): r.append("ctrl")
        if self.alt.isChecked(): r.append("alt")
        if self.shift.isChecked(): r.append("shift")
        if self.win.isChecked(): r.append("win")
        r.append(self.key.currentText().lower().replace(" ","_")); return r
    def _update_preview(self): self.preview.setText(" + ".join(k.upper() for k in self._keys()))
    def _start_recording(self): self.recording=True; self.record.setText("Presiona la combinación…"); self.grabKeyboard()
    def keyPressEvent(self,event):
        if not self.recording: return super().keyPressEvent(event)
        self.ctrl.setChecked(bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)); self.alt.setChecked(bool(event.modifiers() & Qt.KeyboardModifier.AltModifier)); self.shift.setChecked(bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier)); self.win.setChecked(bool(event.modifiers() & Qt.KeyboardModifier.MetaModifier)); text=event.text().upper(); self._set_combo(self.key,text) if text and len(text)==1 else None; self.recording=False; self.releaseKeyboard(); self.record.setText("● Grabar combinación"); self._update_preview()
    @staticmethod
    def _set_combo(combo,value):
        if value and combo.findText(value)<0: combo.addItem(value)
        combo.setCurrentText(value)
