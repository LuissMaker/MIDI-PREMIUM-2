from __future__ import annotations

import os
import sys
import time
from copy import deepcopy

from PySide6.QtCore import QEvent, QTimer, Qt, QSize
from PySide6.QtGui import QAction, QCloseEvent, QIcon, QColor, QPainter, QPixmap
from PySide6.QtWidgets import (
    QCheckBox,
    QButtonGroup,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QDialog,
    QDialogButtonBox,
    QApplication,
    QLabel,
    QMenu,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSystemTrayIcon,
    QVBoxLayout,
    QWidget,
)

from app.actions.engine import ActionEngine
from app.actions.photoshop_psd import list_psd_elements, PhotoshopPsdError
from app.continuous.engine import ContinuousActionEngine
from app.continuous.router import MpkMiniKnobRouter
from app.core.profile_store import ProfileStore
from app.core.secure_store import protect_text, unprotect_text
from app.core.settings import SettingsManager
from app.core.updater import UpdateService, current_version, launch_installer, update_available
from app.midi.engine import MidiEngine
from app.midi.event import MidiEvent
from app.midi.pad_router import MpkMiniPadRouter
from app.obs.engine import ObsEngine
from app.version import __version__
from app.ui.osd import ActionOsd
from app.widgets.action_editor import ActionEditor
from app.widgets.knob_panel import KnobPanel
from app.widgets.config_dialogs import AppSettingsDialog, KnobEditDialog, PadEditDialog, PsdElementPickerDialog, ProfileEditDialog
from app.widgets.midi_monitor import MidiMonitor
from app.widgets.obs_panel import ObsPanel
from app.widgets.pad_widget import PadWidget

DEV_ROOT = __import__("pathlib").Path(__file__).resolve().parents[2]
UI_ICON_DIR = DEV_ROOT / "assets" / "ui_icons"
PAD_ICON_DIR = DEV_ROOT / "assets" / "pad_icons"
PROFILE_ICON_DIR = DEV_ROOT / "assets" / "profile_icons"


class MainWindow(QMainWindow):
    def __init__(
        self,
        settings: SettingsManager,
        profiles: ProfileStore,
        midi_engine: MidiEngine,
        action_engine: ActionEngine,
        obs_engine: ObsEngine,
        continuous_engine: ContinuousActionEngine,
    ) -> None:
        super().__init__()
        self.settings = settings
        self.profiles = profiles
        self.midi_engine = midi_engine
        self.action_engine = action_engine
        self.obs_engine = obs_engine
        self.continuous_engine = continuous_engine
        self.pad_router = MpkMiniPadRouter()
        self.knob_router = MpkMiniKnobRouter()
        self.action_cooldown_seconds = 0.25
        self.last_action_trigger: dict[int, float] = {}
        self._force_quit = False
        self._geometry_save_timer = QTimer(self)
        self._geometry_save_timer.setSingleShot(True)
        self._geometry_save_timer.timeout.connect(self._save_live_geometry)
        self.update_service = UpdateService(self)
        self.update_service.check_finished.connect(self._on_update_check_finished)
        self.update_service.download_progress.connect(self._on_update_download_progress)
        self.update_service.download_finished.connect(self._on_update_download_finished)
        self._pending_update_manifest: dict = {}

        workspace = settings.data["workspace"]
        self.active_bank = str(workspace.get("active_bank", "A"))
        self.selected_pad = int(workspace.get("selected_pad", 1))
        self.stream_mode = bool(workspace.get("stream_mode", False))
        self.compact_mode = bool(workspace.get("compact_mode", True))
        self.compact_editor_open = False
        self.profile_data: dict = {}
        self.pad_widgets: dict[int, PadWidget] = {}
        self._midi_learn_target: str | None = None
        self._midi_learn_dialog = None
        self._joystick_detect_axis: str | None = None
        self._joystick_axis_armed = {"horizontal": True, "vertical": True}
        self._joystick_last_trigger = {"horizontal": 0.0, "vertical": 0.0}
        self._binding_last_trigger: dict[str, float] = {}
        self._initializing = True

        window = settings.data["window"]
        self.resize(
            int(window.get("width", 1180)),
            int(window.get("height", 760)),
        )
        self.setMinimumSize(860, 560)
        self.setWindowTitle(f"MIDI Premium 2 — {__version__}")

        x, y = window.get("x"), window.get("y")
        if isinstance(x, int) and isinstance(y, int):
            self.move(x, y)

        root = QWidget()
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)
        root_layout.addWidget(self._build_top_bar())
        root_layout.addWidget(self._build_workspace(), 1)
        self.osd = ActionOsd()
        self._setup_tray()
        self._sync_windows_startup(bool(self.settings.data.setdefault("workspace", {}).get("start_with_windows", False)))

        self._load_profiles()
        self.change_bank(self.active_bank)
        self.select_pad(self.selected_pad)
        self.set_stream_mode(self.stream_mode)
        self.set_compact_mode(self.compact_mode, initial=True)
        self._connect_midi_module()
        self._connect_obs_module()
        self._initializing = False

        self.statusBar().showMessage(
            "MIDI, acciones y OBS preparados."
        )
        if bool(self.settings.data.setdefault("updates", {}).get("check_on_start", True)):
            QTimer.singleShot(1800, lambda: self.update_service.check_async(interactive=False))

    def _build_top_bar(self) -> QFrame:
        top_bar = QFrame()
        top_bar.setObjectName("TopBar")
        top_bar.setFixedHeight(60)
        layout = QHBoxLayout(top_bar)
        layout.setContentsMargins(18, 0, 18, 0)

        title_block = QVBoxLayout()
        title = QLabel("MIDI Premium 2")
        title.setObjectName("AppTitle")
        self.app_subtitle = QLabel(__version__)
        self.app_subtitle.setObjectName("Muted")
        title_block.addWidget(title)
        title_block.addWidget(self.app_subtitle)
        self.app_subtitle.setVisible(False)

        self.stream_button = QPushButton("Modo Stream")
        self.stream_button.setCheckable(True)
        self.stream_button.clicked.connect(self.set_stream_mode)

        # Botón de modo compacto: solo icono, sin checkbox ni texto.
        # Conservamos el nombre del atributo por compatibilidad con la lógica existente.
        self.compact_checkbox = QPushButton()
        self.compact_checkbox.setCheckable(True)
        self.compact_checkbox.setFixedSize(36, 34)
        compact_icon = UI_ICON_DIR / "compact_mode.svg"
        self.compact_checkbox.setIcon(
            QIcon(self._tinted_svg_pixmap(compact_icon, "#C9D5E4", 18))
        )
        self.compact_checkbox.setIconSize(QSize(18, 18))
        self.compact_checkbox.setToolTip(
            "Alternar modo compacto / modo normal"
        )
        self.compact_checkbox.toggled.connect(self.set_compact_mode)

        self.profile_combo = QComboBox()
        self.profile_combo.setIconSize(QSize(20, 20))
        self.profile_combo.setMinimumWidth(165)
        self.profile_combo.setMaximumWidth(260)
        self.profile_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.profile_combo.currentTextChanged.connect(self.change_profile)
        self.profile_combo.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.profile_combo.customContextMenuRequested.connect(self._show_profile_context_menu)
        self.profile_combo.setToolTip("Selecciona un perfil. Clic derecho para editar nombre e icono.")

        self.add_profile_button = QPushButton()
        self.add_profile_button.setIcon(QIcon(str(UI_ICON_DIR / "add_preset.svg")))
        self.add_profile_button.setToolTip("Añadir preset / perfil")
        self.add_profile_button.setFixedWidth(36)
        self.add_profile_button.clicked.connect(self.create_profile)
        self.routes_button = QPushButton()
        self.routes_button.setFixedSize(36, 34)
        self.routes_button.setIcon(QIcon(self._tinted_svg_pixmap(UI_ICON_DIR / "configuration.svg", "#C9D5E4", 18)))
        self.routes_button.setIconSize(QSize(18, 18))
        self.routes_button.setToolTip("Configuración")
        self.routes_button.clicked.connect(self.open_app_settings)

        layout.addLayout(title_block)
        layout.addStretch()
        layout.addWidget(self.stream_button)
        layout.addWidget(self.compact_checkbox)
        self.profile_label = QLabel("Perfil")
        layout.addWidget(self.profile_label)
        layout.addWidget(self.profile_combo)
        layout.addWidget(self.add_profile_button)
        layout.addWidget(self.routes_button)
        return top_bar

    def _build_workspace(self) -> QWidget:
        self.workspace = QWidget()
        layout = QHBoxLayout(self.workspace)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(8)

        self.controller_panel = self._build_controller_panel()
        self.editor_panel = self._build_editor_panel()
        layout.addWidget(self.controller_panel, 5)
        layout.addWidget(self.editor_panel, 5)
        return self.workspace

    def _build_controller_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("Sidebar")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(6)

        heading = QHBoxLayout()
        title = QLabel("Controlador")
        title.setObjectName("Muted")
        self.device_status_icon = QLabel()
        self.device_status_icon.setFixedSize(18, 18)
        self.device_status = QLabel("MIDI desconectado")
        self.reload_midi_button = QPushButton()
        self.reload_midi_button.setFixedSize(30, 30)
        self.reload_midi_button.setIcon(QIcon(str(UI_ICON_DIR / "reload_midi.svg")))
        self.reload_midi_button.setToolTip("Recargar dispositivos MIDI")
        self.reload_midi_button.clicked.connect(self.reload_midi)
        self._set_midi_status(False, "MIDI desconectado")
        heading.addWidget(title)
        heading.addStretch()

        bank_row = QHBoxLayout()
        self.bank_a_button = QPushButton("BANK A")
        self.bank_a_button.setCheckable(True)
        self.bank_b_button = QPushButton("BANK B")
        self.bank_b_button.setCheckable(True)
        self.bank_group = QButtonGroup(self)
        self.bank_group.setExclusive(True)
        self.bank_group.addButton(self.bank_a_button)
        self.bank_group.addButton(self.bank_b_button)
        # pressed se procesa antes del toggle visual y evita el retraso observado.
        self.bank_a_button.clicked.connect(lambda _=False: self.change_bank("A"))
        self.bank_b_button.clicked.connect(lambda _=False: self.change_bank("B"))
        bank_row.addWidget(self.bank_a_button)
        bank_row.addWidget(self.bank_b_button)
        bank_row.addStretch()
        bank_row.addWidget(self.device_status_icon)
        bank_row.addWidget(self.device_status)
        bank_row.addWidget(self.reload_midi_button)

        pad_container = QWidget(panel)
        grid = QGridLayout(pad_container)
        grid.setContentsMargins(0, 2, 0, 2)
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(6)

        for local_pad in range(1, 9):
            widget = PadWidget(local_pad)
            widget.clicked.connect(self.handle_pad_clicked)
            widget.context_requested.connect(self.show_pad_context_menu)
            self.pad_widgets[local_pad] = widget
            grid.addWidget(
                widget,
                0 if local_pad <= 4 else 1,
                (local_pad - 1) % 4,
                Qt.AlignmentFlag.AlignCenter,
            )

        pad_container.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        pad_container.setMaximumHeight(208)

        self.knob_panel = KnobPanel()
        self.knob_panel.save_requested.connect(
            self.save_knob_configuration
        )
        self.knob_panel.edit_requested.connect(self.open_knob_editor)
        self.knob_panel.context_requested.connect(self.show_knob_context_menu)
        self.midi_monitor = MidiMonitor()

        layout.addLayout(heading)
        layout.addLayout(bank_row)
        layout.addWidget(pad_container)
        layout.addWidget(self.knob_panel)
        layout.addWidget(self.midi_monitor)
        return panel

    def _build_editor_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("EditorPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        editor_heading = QHBoxLayout()
        self.editor_title = QLabel("PAD 01")
        self.editor_title.setObjectName("SectionTitle")
        self.compact_close_button = QPushButton("×")
        self.compact_close_button.setFixedSize(32, 32)
        self.compact_close_button.setToolTip("Cerrar editor y volver al modo compacto")
        self.compact_close_button.clicked.connect(self.close_compact_editor)
        self.compact_close_button.setVisible(False)
        editor_heading.addWidget(self.editor_title)
        editor_heading.addStretch()
        editor_heading.addWidget(self.compact_close_button)

        self.editor_subtitle = QLabel()
        self.editor_subtitle.setObjectName("Muted")
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Ejemplo: Pantalla completa")
        self.obs_panel = ObsPanel()
        self.action_editor = ActionEditor(global_paths=self.settings.data.setdefault("paths", {}))
        self.action_editor.refresh_obs_scenes_requested.connect(
            self.obs_engine.refresh_scenes_async
        )
        self.action_editor.refresh_obs_inputs_requested.connect(
            self.obs_engine.refresh_inputs_async
        )
        self.action_editor.refresh_scene_items_requested.connect(
            self.obs_engine.refresh_scene_items_async
        )

        buttons = QHBoxLayout()
        delete_button = QPushButton("Eliminar")
        delete_button.clicked.connect(self.delete_current_pad)
        test_button = QPushButton("Probar acción")
        test_button.clicked.connect(self.simulate_action)
        save_button = QPushButton("Guardar cambios")
        save_button.clicked.connect(self.save_current_pad)
        buttons.addWidget(delete_button)
        buttons.addStretch()
        buttons.addWidget(test_button)
        buttons.addWidget(save_button)

        layout.addLayout(editor_heading)
        layout.addWidget(self.editor_subtitle)
        layout.addWidget(QLabel("Nombre del pad"))
        layout.addWidget(self.name_input)
        layout.addWidget(QLabel("Tipo de acción"))
        layout.addWidget(self.action_editor, 1)
        layout.addWidget(self.obs_panel)
        layout.addLayout(buttons)
        self.action_editor.action_type_changed.connect(self._sync_main_obs_visibility)
        self._sync_main_obs_visibility(str(self.action_editor.action_combo.currentData()))
        return panel

    def _sync_main_obs_visibility(self, action_type: str) -> None:
        self.obs_panel.setVisible(str(action_type).startswith("obs_"))

    def _connect_midi_module(self) -> None:
        midi_settings = self.settings.data.setdefault("midi", {})
        preferred = str(midi_settings.get("preferred_device", ""))
        auto_reconnect = bool(midi_settings.get("auto_reconnect", True))
        self.midi_engine.configure_reconnect(preferred, auto_reconnect)

        self.midi_monitor.refresh_requested.connect(
            self.midi_engine.refresh_devices
        )
        self.midi_monitor.connect_requested.connect(
            self.connect_midi_device
        )
        self.midi_monitor.disconnect_requested.connect(
            self.midi_engine.disconnect_device
        )

        self.midi_engine.devices_changed.connect(self.handle_midi_devices)
        self.midi_engine.connected.connect(self.handle_midi_connected)
        self.midi_engine.disconnected.connect(self.handle_midi_disconnected)
        self.midi_engine.event_received.connect(self.handle_midi_event)
        self.midi_engine.error_occurred.connect(self.handle_midi_error)

        devices = self.midi_engine.refresh_devices()
        selected = self.midi_engine.choose_default_device(devices, preferred)
        self.midi_monitor.set_devices(devices, selected)

        if bool(midi_settings.get("auto_connect", True)):
            QTimer.singleShot(250, self.midi_engine.auto_connect)

    def connect_midi_device(self, device_name: str) -> None:
        if self.midi_engine.connect_device(device_name):
            self.settings.data.setdefault("midi", {})[
                "preferred_device"
            ] = device_name
            self.settings.save()

    def handle_midi_devices(self, devices: list[str]) -> None:
        preferred = str(
            self.settings.data.setdefault("midi", {}).get(
                "preferred_device",
                "",
            )
        )
        selected = self.midi_engine.choose_default_device(devices, preferred)
        self.midi_monitor.set_devices(devices, selected)

    def _tinted_svg_pixmap(self, path, color: str, size: int = 16) -> QPixmap:
        pix = QIcon(str(path)).pixmap(size, size)
        if pix.isNull():
            return pix
        result = QPixmap(pix.size())
        result.fill(Qt.GlobalColor.transparent)
        painter = QPainter(result)
        painter.drawPixmap(0, 0, pix)
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
        painter.fillRect(result.rect(), QColor(color))
        painter.end()
        return result

    def _set_midi_status(self, connected: bool, text: str) -> None:
        color = "#63D98A" if connected else "#F06A6A"
        icon = self._tinted_svg_pixmap(UI_ICON_DIR / "midi_status.svg", color, 16)
        self.device_status_icon.setPixmap(icon)
        self.device_status_icon.setStyleSheet("background:transparent;")
        self.device_status.setText(text)
        self.device_status.setStyleSheet(f"color:{color}; font-weight:700;")

    def reload_midi(self) -> None:
        devices = self.midi_engine.refresh_devices()
        preferred = str(self.settings.data.setdefault("midi", {}).get("preferred_device", ""))
        selected = self.midi_engine.choose_default_device(devices, preferred)
        self.midi_monitor.set_devices(devices, selected)
        if selected:
            self.connect_midi_device(selected)
        else:
            self._set_midi_status(False, "MIDI desconectado")
            self.statusBar().showMessage("No se encontró un dispositivo MIDI compatible.", 3000)

    def handle_midi_connected(self, device_name: str) -> None:
        self._set_midi_status(True, "MIDI conectado")
        self.midi_monitor.set_connected(device_name)
        self.settings.data.setdefault("midi", {})[
            "preferred_device"
        ] = device_name
        self.settings.save()

    def handle_midi_disconnected(self, reason: str) -> None:
        self._set_midi_status(False, "MIDI desconectado")
        self.midi_monitor.set_disconnected(reason)

    def handle_midi_error(self, message: str) -> None:
        self._set_midi_status(False, "Error MIDI")
        self.midi_monitor.set_error(message)

    def handle_midi_event(self, event: MidiEvent) -> None:
        self.midi_monitor.append_event(event)

        dialog = self._midi_learn_dialog
        if dialog is not None and hasattr(dialog, "append_midi_test_event"):
            dialog.append_midi_test_event(event)
            if getattr(dialog, "is_midi_test_listening", lambda: False)():
                return

        # Detección de eje de palanca: acepta pitchwheel o CC y no ejecuta acciones.
        if self._joystick_detect_axis:
            signature = self._joystick_event_signature(event)
            if signature:
                axis = self._joystick_detect_axis
                self._joystick_detect_axis = None
                dialog = self._midi_learn_dialog
                if dialog is not None and hasattr(dialog, "set_joystick_axis"):
                    dialog.set_joystick_axis(axis, signature, event.summary())
                self.show_toast(f"Eje {axis} detectado: {event.summary()}")
                return

        # MIDI Learn captura el siguiente control físico sin ejecutar su acción normal.
        if self._midi_learn_target:
            signature = self._event_binding_signature(event)
            if signature:
                target = self._midi_learn_target
                self._midi_learn_target = None
                dialog = self._midi_learn_dialog
                if dialog is not None:
                    dialog.set_learned_binding(target, signature, event.summary())
                self.show_toast(f"Control MIDI aprendido: {event.summary()}")
                return

        if self._dispatch_global_midi_binding(event):
            return

        if self._dispatch_joystick(event):
            return

        knob_route=self.knob_router.route(event)
        if knob_route is not None:
            cfg=self.knob_panel.knob_config(knob_route.knob)
            self.knob_panel.update_value(knob_route.knob,knob_route.value)
            self._show_knob_osd(knob_route.knob, knob_route.value, cfg)
            self.continuous_engine.update_knob(knob_route.knob,knob_route.value,cfg)
            return

        route = self.pad_router.route(event)
        if route is None:
            return

        if event.is_release:
            self.pad_widgets[route.local_pad].set_activity(False)
            return

        if not event.is_press:
            return

        # El BANK seleccionado en MIDI Premium manda. Los mensajes de nota del
        # controlador pueden pertenecer a un banco físico distinto, pero nunca
        # deben hacer que BANK B ejecute una asignación de BANK A (o viceversa).
        display_number = route.local_pad if self.active_bank == "A" else route.local_pad + 8

        self.select_pad(route.local_pad)
        self.pad_widgets[route.local_pad].set_activity(True)
        self.execute_pad_action(display_number)



    @staticmethod
    def _event_binding_signature(event: MidiEvent) -> str:
        # Solo capturamos eventos utilizables como botones. Para CC/nota se guarda
        # canal + número; el valor/velocidad no forma parte del identificador.
        if event.type in {"note_on", "note_off"} and event.note is not None:
            if event.type == "note_off" or (event.velocity or 0) <= 0:
                return ""
            return f"note:{event.channel if event.channel is not None else -1}:{int(event.note)}"
        if event.type == "control_change" and event.control is not None:
            if (event.value or 0) <= 0:
                return ""
            return f"cc:{event.channel if event.channel is not None else -1}:{int(event.control)}"
        if event.type == "program_change" and event.program is not None:
            return f"program:{event.channel if event.channel is not None else -1}:{int(event.program)}"
        return ""

    @staticmethod
    def _joystick_event_signature(event: MidiEvent) -> str:
        if event.type == "pitchwheel" and event.pitch is not None:
            return f"pitch:{event.channel if event.channel is not None else -1}"
        if event.type == "control_change" and event.control is not None:
            return f"cc:{event.channel if event.channel is not None else -1}:{int(event.control)}"
        return ""

    @staticmethod
    def _normalized_joystick_value(event: MidiEvent) -> float | None:
        if event.type == "pitchwheel" and event.pitch is not None:
            value = float(event.pitch) / 8192.0
            return max(-1.0, min(1.0, value))
        if event.type == "control_change" and event.value is not None:
            # Ejes CC de joystick suelen usar 64 como centro, 0/127 como extremos.
            value = (float(event.value) - 64.0) / 63.0
            return max(-1.0, min(1.0, value))
        return None

    def _execute_joystick_action(self, action: str) -> None:
        action = str(action or "none")
        if action == "profile_prev": self.previous_profile()
        elif action == "profile_next": self.next_profile()
        elif action == "bank_a": self.change_bank("A")
        elif action == "bank_b": self.change_bank("B")
        elif action == "bank_toggle": self.change_bank("B" if self.active_bank == "A" else "A")
        elif action == "show_hide":
            if self.isVisible() and not self.isMinimized(): self.hide()
            else: self.show_from_tray()

    def _dispatch_joystick(self, event: MidiEvent) -> bool:
        cfg = dict(self.settings.data.setdefault("midi", {}).get("joystick", {}) or {})
        signature = self._joystick_event_signature(event)
        if not signature:
            return False
        axis = ""
        if signature and signature == str(cfg.get("horizontal_signature", "")).strip():
            axis = "horizontal"
        elif signature and signature == str(cfg.get("vertical_signature", "")).strip():
            axis = "vertical"
        if not axis:
            return False
        value = self._normalized_joystick_value(event)
        if value is None:
            return True
        threshold = max(0.35, min(0.95, float(cfg.get("threshold", 0.65))))
        deadzone = max(0.05, min(0.35, float(cfg.get("center_deadzone", 0.18))))
        cooldown = max(0.10, float(cfg.get("cooldown_ms", 300)) / 1000.0)

        # Volver al centro rearma el eje. Mientras no vuelva, ningún mensaje extra
        # puede cambiar varios perfiles/bancos durante una sola inclinación.
        if abs(value) <= deadzone:
            self._joystick_axis_armed[axis] = True
            return True
        if not self._joystick_axis_armed.get(axis, True):
            return True
        now = time.monotonic()
        if now - self._joystick_last_trigger.get(axis, 0.0) < cooldown:
            return True
        if value >= threshold:
            action = cfg.get("right_action" if axis == "horizontal" else "up_action", "none")
        elif value <= -threshold:
            action = cfg.get("left_action" if axis == "horizontal" else "down_action", "none")
        else:
            return True
        self._joystick_axis_armed[axis] = False
        self._joystick_last_trigger[axis] = now
        self._execute_joystick_action(str(action))
        return True

    def _dispatch_global_midi_binding(self, event: MidiEvent) -> bool:
        signature = self._event_binding_signature(event)
        if not signature:
            return False
        bindings = dict(self.settings.data.setdefault("midi", {}).get("bindings", {}) or {})
        key = next((k for k, v in bindings.items() if str(v).strip() == signature), "")
        if not key:
            return False
        now = time.monotonic()
        if now - self._binding_last_trigger.get(key, 0.0) < 0.30:
            return True
        self._binding_last_trigger[key] = now
        if key == "profile_prev": self.previous_profile()
        elif key == "profile_next": self.next_profile()
        elif key == "bank_a": self.change_bank("A")
        elif key == "bank_b": self.change_bank("B")
        elif key == "bank_toggle": self.change_bank("B" if self.active_bank == "A" else "A")
        elif key == "show_hide":
            if self.isVisible() and not self.isMinimized(): self.hide()
            else: self.show_from_tray()
        else: return False
        return True

    def _connect_obs_module(self) -> None:
        obs_settings = self.settings.data.setdefault("obs", {})
        try:
            password = unprotect_text(
                str(obs_settings.get("password_protected", ""))
            )
        except Exception:
            password = ""

        visible_settings = {
            "host": obs_settings.get("host", "localhost"),
            "port": obs_settings.get("port", 4455),
            "password": password,
            "auto_reconnect": obs_settings.get(
                "auto_reconnect",
                True,
            ),
        }
        self.obs_panel.set_settings(visible_settings)

        self.obs_panel.connect_requested.connect(
            self.connect_obs
        )
        self.obs_panel.disconnect_requested.connect(
            self.obs_engine.disconnect
        )
        self.obs_panel.refresh_requested.connect(
            self.obs_engine.refresh_scenes_async
        )

        self.obs_engine.connected.connect(
            self.handle_obs_connected
        )
        self.obs_engine.disconnected.connect(
            self.handle_obs_disconnected
        )
        self.obs_engine.scenes_changed.connect(self.handle_obs_scenes)
        self.obs_engine.inputs_changed.connect(self.handle_obs_inputs)
        self.obs_engine.scene_items_changed.connect(
            self.handle_obs_scene_items
        )
        self.obs_engine.error_occurred.connect(
            self.handle_obs_error
        )

        self.continuous_engine.value_applied.connect(self.handle_continuous_value_applied)
        self.continuous_engine.error_occurred.connect(self.handle_continuous_error)

        self.obs_engine.configure(
            str(obs_settings.get("host", "localhost")),
            int(obs_settings.get("port", 4455)),
            password,
            bool(obs_settings.get("auto_reconnect", True)),
        )

        if bool(obs_settings.get("auto_connect", False)):
            QTimer.singleShot(500, self.obs_engine.connect_async)

    def connect_obs(self, data: dict) -> None:
        try:
            protected = protect_text(str(data.get("password", "")))
        except Exception as exc:
            self.handle_obs_error(
                f"No se pudo proteger la contraseña: {exc}"
            )
            return

        obs_settings = self.settings.data.setdefault("obs", {})
        obs_settings.update(
            {
                "host": str(data.get("host", "localhost")),
                "port": int(data.get("port", 4455)),
                "password_protected": protected,
                "auto_connect": True,
                "auto_reconnect": bool(
                    data.get("auto_reconnect", True)
                ),
            }
        )
        self.settings.save()

        self.obs_engine.configure(
            obs_settings["host"],
            obs_settings["port"],
            str(data.get("password", "")),
            obs_settings["auto_reconnect"],
        )
        self.obs_engine.connect_async()

    def handle_obs_connected(self, info: dict) -> None:
        self.obs_panel.set_connected(info)
        self.obs_engine.refresh_inputs_async()
        self.statusBar().showMessage(
            "OBS conectado y autenticado.",
            3500,
        )

    def handle_obs_disconnected(self, message: str) -> None:
        self.obs_panel.set_disconnected(message)
        self.statusBar().showMessage("OBS desconectado", 3500)
        self.statusBar().setToolTip(f"OBS: {message}" if message else "OBS desconectado")

    def handle_obs_error(self, message: str) -> None:
        self.obs_panel.set_error(message)
        self.statusBar().showMessage("OBS desconectado", 4500)
        self.statusBar().setToolTip(f"OBS: {message}")

    def handle_obs_scenes(self, scenes: list[str]) -> None:
        self.action_editor.set_obs_scenes(scenes)
        self.statusBar().showMessage(
            f"OBS: {len(scenes)} escenas detectadas.",
            3000,
        )

    def handle_obs_inputs(self, inputs: list[str]) -> None:
        self.knob_panel.set_sources(inputs)
        self.action_editor.set_obs_inputs(inputs)

    def handle_obs_scene_items(
        self,
        scene_name: str,
        items: list[dict],
    ) -> None:
        self.action_editor.set_scene_items(scene_name, items)
        self.statusBar().showMessage(
            f"OBS: {len(items)} fuentes en «{scene_name}».",
            3000,
        )

    def save_knob_configuration(self) -> None:
        self.profile_data["knobs"]=self.knob_panel.get_config()
        self.profiles.save(self.profile_combo.currentText(),self.profile_data)
        self.statusBar().showMessage("Configuración de perillas guardada.",3000)

    def handle_continuous_value_applied(self, knob:int, midi_value:int, db:float) -> None:
        self.knob_panel.update_value(knob,midi_value,db)

    def handle_continuous_error(self, knob:int, message:str) -> None:
        self.knob_panel.set_error(knob,message)
        self.statusBar().showMessage(f"K{knob}: {message}",5000)

    def _load_profiles(self) -> None:
        names = self.profiles.list_profiles()
        requested = str(
            self.settings.data["workspace"].get("active_profile", "General")
        )
        if requested not in names:
            requested = names[0]

        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for profile_name in names:
            try:
                pdata = self.profiles.load(profile_name)
                icon_name = str(pdata.get("icon", "") or "").strip()
            except Exception:
                icon_name = ""
            icon_path = PROFILE_ICON_DIR / icon_name if icon_name else None
            if icon_path is not None and icon_path.exists():
                self.profile_combo.addItem(QIcon(str(icon_path)), profile_name)
            else:
                self.profile_combo.addItem(profile_name)
        self.profile_combo.setCurrentText(requested)
        self.profile_combo.blockSignals(False)
        self.change_profile(requested)

    def create_profile(self) -> None:
        name, accepted = QInputDialog.getText(
            self,
            "Nuevo perfil",
            "Nombre del perfil:",
        )
        name = name.strip()
        if not accepted or not name:
            return
        self.profiles.create(name)
        self._load_profiles()
        self.profile_combo.setCurrentText(name)

    def _show_profile_context_menu(self, pos) -> None:
        menu = QMenu(self.profile_combo)
        edit_action = menu.addAction("Editar perfil…")
        duplicate_action = menu.addAction("Duplicar perfil…")
        delete_action = menu.addAction("Eliminar perfil…")
        icon_name = str(self.profile_data.get("icon", "") or "").strip() if self.profile_data else ""
        icon_path = PROFILE_ICON_DIR / icon_name if icon_name else None
        if icon_path is not None and icon_path.exists():
            profile_icon = QIcon(str(icon_path))
            edit_action.setIcon(profile_icon)
            duplicate_action.setIcon(profile_icon)
        chosen = menu.exec(self.profile_combo.mapToGlobal(pos))
        if chosen == edit_action:
            self.edit_current_profile()
        elif chosen == duplicate_action:
            self.duplicate_current_profile()
        elif chosen == delete_action:
            self.delete_current_profile()

    def edit_current_profile(self) -> None:
        old_name = self.profile_combo.currentText().strip()
        if not old_name:
            return
        icon_name = str(self.profile_data.get("icon", "") or "").strip() if self.profile_data else ""
        dialog = ProfileEditDialog(old_name, icon_name, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        new_name = dialog.profile_name()
        if not new_name:
            QMessageBox.warning(self, "Editar perfil", "El nombre del perfil no puede estar vacío.")
            return
        try:
            self.profile_data["knobs"] = self.knob_panel.get_config()
            self.profile_data["icon"] = dialog.icon_name
            self.profile_data["name"] = new_name
            self.profiles.save(old_name, self.profile_data)
            if new_name != old_name:
                self.profiles.rename(old_name, new_name)
        except Exception as exc:
            QMessageBox.warning(self, "Editar perfil", str(exc))
            return
        self.settings.data.setdefault("workspace", {})["active_profile"] = new_name
        self.settings.save()
        self._load_profiles()
        self.profile_combo.setCurrentText(new_name)
        self._show_profile_osd(new_name)

    def duplicate_current_profile(self) -> None:
        source_name = self.profile_combo.currentText().strip()
        if not source_name:
            return
        suggested = f"{source_name} copia"
        # Buscar un nombre sugerido que no choque con perfiles existentes.
        existing = {name.lower() for name in self.profiles.list_profiles()}
        if suggested.lower() in existing:
            n = 2
            while f"{source_name} copia {n}".lower() in existing:
                n += 1
            suggested = f"{source_name} copia {n}"
        new_name, accepted = QInputDialog.getText(
            self, "Duplicar perfil", "Nombre de la copia:", text=suggested
        )
        new_name = str(new_name or "").strip()
        if not accepted or not new_name:
            return
        if new_name.lower() in existing:
            QMessageBox.warning(self, "Duplicar perfil", f"Ya existe un perfil llamado «{new_name}».")
            return
        try:
            self.profile_data["knobs"] = self.knob_panel.get_config()
            self.profiles.save(source_name, self.profile_data)
            copied = deepcopy(self.profile_data)
            copied["name"] = new_name
            self.profiles.save(new_name, copied)
        except Exception as exc:
            QMessageBox.warning(self, "Duplicar perfil", str(exc))
            return
        self.settings.data.setdefault("workspace", {})["active_profile"] = new_name
        self.settings.save()
        self._load_profiles()
        self.profile_combo.setCurrentText(new_name)
        self._show_profile_osd(new_name)

    def delete_current_profile(self) -> None:
        name = self.profile_combo.currentText().strip()
        if not name:
            return
        names = self.profiles.list_profiles()
        if len(names) <= 1:
            QMessageBox.information(
                self, "Eliminar perfil", "Debe existir al menos un perfil."
            )
            return
        answer = QMessageBox.question(
            self,
            "Eliminar perfil",
            f"¿Eliminar el perfil «{name}»?\n\nEsta acción eliminará sus BANK, PADs, perillas e icono asignado.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.profiles.delete(name)
        except Exception as exc:
            QMessageBox.warning(self, "Eliminar perfil", str(exc))
            return
        remaining = self.profiles.list_profiles()
        next_name = remaining[0]
        self.settings.data.setdefault("workspace", {})["active_profile"] = next_name
        self.settings.save()
        self._load_profiles()
        self.profile_combo.setCurrentText(next_name)

    def previous_profile(self) -> None:
        count = self.profile_combo.count()
        if count <= 1:
            return
        self.profile_combo.setCurrentIndex((self.profile_combo.currentIndex() - 1) % count)

    def next_profile(self) -> None:
        count = self.profile_combo.count()
        if count <= 1:
            return
        self.profile_combo.setCurrentIndex((self.profile_combo.currentIndex() + 1) % count)

    def show_toast(self, text: str) -> None:
        if not hasattr(self, "toast_label"):
            self.toast_label = QLabel(self)
            self.toast_label.setStyleSheet("background:#202833; color:#F3F7FF; border:1px solid #3A4657; border-radius:10px; padding:10px 18px; font-weight:700;")
            self.toast_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.toast_label.setText(text)
        self.toast_label.adjustSize()
        x = max(8, (self.width() - self.toast_label.width()) // 2)
        y = max(8, self.height() - self.toast_label.height() - 58)
        self.toast_label.move(x, y)
        self.toast_label.show()
        self.toast_label.raise_()
        QTimer.singleShot(1600, self.toast_label.hide)

    def _show_pad_osd(self, display_number: int) -> None:
        workspace = self.settings.data.setdefault("workspace", {})
        if not bool(workspace.get("show_action_osd", True)):
            return
        data = self.pad_data(display_number)
        name = str(data.get("name", "") or "").strip()
        if not name or name == "Sin asignar":
            name = f"PAD {display_number:02d}"
        bank = "A" if int(display_number) <= 8 else "B"
        icon_name = str(data.get("icon", "") or "").strip()
        icon_path = PAD_ICON_DIR / icon_name if icon_name else None
        self.osd.show_pad(
            name=name,
            bank=bank,
            icon_path=icon_path,
            duration_ms=int(workspace.get("osd_duration_ms", 1400)),
            show_icon=bool(workspace.get("osd_show_icon", True)),
            show_bank=bool(workspace.get("osd_show_bank", True)),
        )

    def _show_knob_osd(self, knob: int, midi_value: int, cfg: dict) -> None:
        workspace = self.settings.data.setdefault("workspace", {})
        if not bool(workspace.get("show_knob_osd", True)):
            return
        typ = str((cfg or {}).get("type", "none"))
        if typ == "none":
            return
        percent = round(max(0, min(127, int(midi_value))) * 100 / 127)
        custom_name = str((cfg or {}).get("name", "") or "").strip()
        source = str((cfg or {}).get("source", "") or "").strip()
        if custom_name:
            label = f"K{knob} · {custom_name}"
        elif source:
            label = f"K{knob} · {source}"
        else:
            label = f"K{knob}"
        if typ == "obs_volume":
            db = self.continuous_engine.midi_to_db(int(midi_value), cfg or {})
            value_text = "Silencio · 0%" if int(midi_value) <= 0 else f"{db:.1f} dB · {percent}%"
        else:
            value_text = f"{percent}%"
        self.osd.show_knob(
            label=label,
            percent=percent,
            value_text=value_text,
            duration_ms=int(workspace.get("knob_osd_duration_ms", 950)),
        )

    def _show_profile_osd(self, name: str) -> None:
        if self._initializing:
            return
        icon_name = str(self.profile_data.get("icon", "") or "").strip() if self.profile_data else ""
        icon_path = PROFILE_ICON_DIR / icon_name if icon_name else None
        self.osd.show_message(
            str(name or "Perfil"),
            duration_ms=1200,
            icon_path=icon_path if icon_path is not None and icon_path.exists() else None,
        )

    def change_profile(self, name: str) -> None:
        if not name:
            return
        self.profile_data = self.profiles.load(name)
        self.knob_panel.set_config(self.profile_data.get("knobs",{}))
        self.settings.data["workspace"]["active_profile"] = name
        self.settings.save()
        self.refresh_pad_titles()
        self.load_current_pad()
        if not self._initializing:
            self.show_toast(name)
            self._show_profile_osd(name)

    def current_display_number(self) -> int:
        return self.selected_pad if self.active_bank == "A" else self.selected_pad + 8

    def change_bank(self, bank: str) -> None:
        bank = "B" if str(bank).upper() == "B" else "A"
        self.active_bank = bank
        self.bank_a_button.setChecked(bank == "A")
        self.bank_b_button.setChecked(bank == "B")
        self.bank_a_button.setProperty("activeBank", bank == "A")
        self.bank_b_button.setProperty("activeBank", bank == "B")
        active_style = "background-color:#2D7DFF; border:1px solid #2D7DFF; color:white; font-weight:600;"
        inactive_style = ""
        self.bank_a_button.setStyleSheet(active_style if bank == "A" else inactive_style)
        self.bank_b_button.setStyleSheet(active_style if bank == "B" else inactive_style)
        self.bank_a_button.style().unpolish(self.bank_a_button); self.bank_a_button.style().polish(self.bank_a_button)
        self.bank_b_button.style().unpolish(self.bank_b_button); self.bank_b_button.style().polish(self.bank_b_button)
        self.settings.data["workspace"]["active_bank"] = bank
        self.settings.save()

        offset = 0 if bank == "A" else 8
        for local_pad, widget in self.pad_widgets.items():
            widget.number_label.setText(f"{local_pad + offset:02d}")
            widget.subtitle_label.setText(f"BANK {bank}")

        self.refresh_pad_titles()
        self.select_pad(self.selected_pad)
        # Fuerza el refresco en el mismo ciclo del clic; evita que BANK B parezca
        # cambiar solo después de presionar un PAD físico.
        for widget in self.pad_widgets.values():
            widget.update(); widget.repaint()
        self.bank_a_button.update(); self.bank_b_button.update()
        QApplication.processEvents()
        self.show_toast(f"BANK {bank}")
        if not self._initializing:
            # Lanzarlo en el siguiente ciclo evita que el repintado de BANK
            # o el clic del botón tape/cancele el OSD.
            QTimer.singleShot(0, lambda b=bank: self.osd.show_message(f"BANK {b}", duration_ms=1050, icon_text=b))

    def select_pad(self, local_pad: int) -> None:
        self.selected_pad = max(1, min(8, int(local_pad)))
        self.settings.data["workspace"]["selected_pad"] = self.selected_pad
        self.settings.save()

        for pad, widget in self.pad_widgets.items():
            widget.set_selected(pad == self.selected_pad)

        display_number = self.current_display_number()
        self.editor_title.setText(f"PAD {display_number:02d}")
        self.editor_subtitle.setText(
            f"Bank {self.active_bank} · Posición física {self.selected_pad}"
        )
        self.load_current_pad()

    def handle_pad_clicked(self, local_pad: int) -> None:
        self.select_pad(local_pad)

    def show_pad_context_menu(self, local_pad: int) -> None:
        self.select_pad(local_pad)
        menu = QMenu(self)
        edit_action = menu.addAction(QIcon(str(UI_ICON_DIR / "edit_pad.svg")), "Editar PAD")
        test_action = menu.addAction(QIcon(str(UI_ICON_DIR / "test_action.svg")), "Probar acción")
        copy_action = menu.addAction(QIcon(str(UI_ICON_DIR / "copy_to.svg")), "Copiar en…")
        menu.addSeparator()
        clear_action = menu.addAction(QIcon(str(UI_ICON_DIR / "clear_pad.svg")), "Limpiar PAD")
        chosen = menu.exec(self.cursor().pos())
        if chosen == edit_action:
            self.open_pad_editor(local_pad)
        elif chosen == test_action:
            self.simulate_action()
        elif chosen == copy_action:
            self.copy_current_pad_to()
        elif chosen == clear_action:
            self.delete_current_pad()

    def copy_current_pad_to(self) -> None:
        source_number = self.current_display_number()
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Copiar PAD {source_number:02d}")
        dialog.resize(430, 230)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Selecciona dónde copiar esta configuración."))
        target = QComboBox()
        for n in range(1, 17):
            bank = "A" if n <= 8 else "B"
            local = n if n <= 8 else n - 8
            if n != source_number:
                target.addItem(f"BANK {bank} · PAD {local}  (PAD {n:02d})", n)
        mode = QComboBox()
        mode.addItem("Todo: nombre + icono + acción", "all")
        mode.addItem("Solo acción", "action")
        mode.addItem("Solo nombre e icono", "appearance")
        layout.addWidget(QLabel("Destino")); layout.addWidget(target)
        layout.addWidget(QLabel("Qué copiar")); layout.addWidget(mode)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Copiar")
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        target_number = int(target.currentData())
        src = deepcopy(self.pad_data(source_number))
        dst = self.pad_data(target_number)
        selected_mode = str(mode.currentData())
        if selected_mode == "all":
            self.profile_data.setdefault("pads", {})[str(target_number)] = src
        elif selected_mode == "action":
            dst["action"] = deepcopy(src.get("action", {"type":"none"}))
        else:
            dst["name"] = src.get("name", "Sin asignar")
            dst["icon"] = src.get("icon", "")
        self.profiles.save(self.profile_combo.currentText(), self.profile_data)
        self.refresh_pad_titles()
        self.show_toast(f"PAD {source_number:02d} copiado a PAD {target_number:02d}")

    def _visible_obs_settings(self) -> dict:
        obs_settings = self.settings.data.setdefault("obs", {})
        try:
            password = unprotect_text(str(obs_settings.get("password_protected", "")))
        except Exception:
            password = ""
        return {
            "host": obs_settings.get("host", "localhost"),
            "port": obs_settings.get("port", 4455),
            "password": password,
            "auto_reconnect": obs_settings.get("auto_reconnect", True),
        }

    def open_pad_editor(self, local_pad: int) -> None:
        self.select_pad(local_pad)
        display_number = self.current_display_number()
        dialog = PadEditDialog(
            display_number,
            self.active_bank,
            self.selected_pad,
            dict(self.pad_data(display_number)),
            self._visible_obs_settings(),
            global_paths=self.settings.data.setdefault("paths", {}),
            dialog_size=self.settings.data.setdefault("window", {}).get("pad_editor", {}),
            parent=self,
        )

        obs_wired = {"value": False}

        def wire_obs(needed: bool) -> None:
            if not needed or obs_wired["value"]:
                return
            obs_wired["value"] = True
            dialog.obs_panel.connect_requested.connect(self.connect_obs)
            dialog.obs_panel.disconnect_requested.connect(self.obs_engine.disconnect)
            dialog.obs_panel.refresh_requested.connect(self.obs_engine.refresh_scenes_async)
            dialog.action_editor.refresh_obs_scenes_requested.connect(self.obs_engine.refresh_scenes_async)
            dialog.action_editor.refresh_obs_inputs_requested.connect(self.obs_engine.refresh_inputs_async)
            dialog.action_editor.refresh_scene_items_requested.connect(self.obs_engine.refresh_scene_items_async)
            self.obs_engine.scenes_changed.connect(dialog.action_editor.set_obs_scenes)
            self.obs_engine.inputs_changed.connect(dialog.action_editor.set_obs_inputs)
            self.obs_engine.scene_items_changed.connect(dialog.action_editor.set_scene_items)
            self.obs_engine.connected.connect(dialog.obs_panel.set_connected)
            self.obs_engine.disconnected.connect(dialog.obs_panel.set_disconnected)
            self.obs_engine.error_occurred.connect(dialog.obs_panel.set_error)
            # Se difiere para que la ventana aparezca primero y no parezca trabada.
            QTimer.singleShot(0, self.obs_engine.refresh_scenes_async)
            QTimer.singleShot(0, self.obs_engine.refresh_inputs_async)

        dialog.obs_needed.connect(wire_obs)
        wire_obs(PadEditDialog.is_obs_action(str(dialog.action_editor.action_combo.currentData())))
        accepted = dialog.exec() == QDialog.DialogCode.Accepted
        self.settings.data.setdefault("window", {})["pad_editor"] = dialog.saved_size()
        self.settings.save()

        if obs_wired["value"]:
            try:
                self.obs_engine.scenes_changed.disconnect(dialog.action_editor.set_obs_scenes)
                self.obs_engine.inputs_changed.disconnect(dialog.action_editor.set_obs_inputs)
                self.obs_engine.scene_items_changed.disconnect(dialog.action_editor.set_scene_items)
                self.obs_engine.connected.disconnect(dialog.obs_panel.set_connected)
                self.obs_engine.disconnected.disconnect(dialog.obs_panel.set_disconnected)
                self.obs_engine.error_occurred.disconnect(dialog.obs_panel.set_error)
            except Exception:
                pass

        if accepted:
            data = self.pad_data(display_number)
            data.update(dialog.result_data())
            self.profiles.save(self.profile_combo.currentText(), self.profile_data)
            self.refresh_pad_titles()
            self.load_current_pad()
            self.statusBar().showMessage(f"PAD {display_number:02d} guardado.", 3000)

    def open_knob_editor(self, knob: int) -> None:
        current = self.knob_panel.knob_config(knob)
        sources = [self.knob_panel.cards[knob].source.itemText(i) for i in range(self.knob_panel.cards[knob].source.count())]
        dialog = KnobEditDialog(knob, current, sources, self.settings.data.setdefault("window", {}).get("knob_editor", {}), self)
        accepted = dialog.exec() == QDialog.DialogCode.Accepted
        self.settings.data.setdefault("window", {})["knob_editor"] = dialog.saved_size()
        self.settings.save()
        if not accepted:
            return
        self.knob_panel.set_knob_config(knob, dialog.result_config())
        self.save_knob_configuration()


    def show_knob_context_menu(self, knob: int) -> None:
        menu = QMenu(self)
        edit_action = menu.addAction(QIcon(str(UI_ICON_DIR / "edit_pad.svg")), f"Editar perilla K{knob}")
        test_action = menu.addAction(QIcon(str(UI_ICON_DIR / "test_action.svg")), "Probar acción")
        copy_action = menu.addAction(QIcon(str(UI_ICON_DIR / "copy_to.svg")), "Copiar en…")
        menu.addSeparator()
        clear_action = menu.addAction(QIcon(str(UI_ICON_DIR / "clear_pad.svg")), "Limpiar perilla")
        chosen = menu.exec(self.cursor().pos())
        if chosen == edit_action:
            self.open_knob_editor(knob)
        elif chosen == test_action:
            self.test_knob_action(knob)
        elif chosen == copy_action:
            self.copy_knob_to(knob)
        elif chosen == clear_action:
            self.knob_panel.clear_knob(knob)
            self.save_knob_configuration()
            self.show_toast(f"K{knob} limpiada")

    def test_knob_action(self, knob: int) -> None:
        cfg = self.knob_panel.knob_config(knob)
        value = self.knob_panel.last_value(knob)
        self.continuous_engine.update_knob(knob, value, cfg)
        self.show_toast(f"Probando K{knob} · valor {value}")

    def copy_knob_to(self, source_knob: int) -> None:
        targets = [f"K{i}" for i in range(1, 9) if i != int(source_knob)]
        choice, ok = QInputDialog.getItem(self, f"Copiar K{source_knob}", "Destino", targets, 0, False)
        if not ok or not choice:
            return
        target = int(str(choice).replace("K", ""))
        self.knob_panel.set_knob_config(target, deepcopy(self.knob_panel.knob_config(source_knob)))
        self.save_knob_configuration()
        self.show_toast(f"K{source_knob} copiada a K{target}")

    def pad_data(self, display_number: int) -> dict:
        pads = self.profile_data.setdefault("pads", {})
        return pads.setdefault(
            str(display_number),
            {"name": "Sin asignar", "icon": "", "action": {"type": "none"}},
        )

    def refresh_pad_titles(self) -> None:
        if not self.profile_data:
            return
        offset = 0 if self.active_bank == "A" else 8
        for local_pad, widget in self.pad_widgets.items():
            data = self.pad_data(local_pad + offset)
            widget.set_title(str(data.get("name", "Sin asignar")))
            widget.set_icon(str(data.get("icon", "") or ""))

    def load_current_pad(self) -> None:
        if not self.profile_data:
            return
        data = self.pad_data(self.current_display_number())
        self.name_input.setText(
            "" if data.get("name") == "Sin asignar" else str(data.get("name", ""))
        )
        self.action_editor.set_action(
            data.get("action", {"type": "none"})
        )

    def save_current_pad(self) -> None:
        display_number = self.current_display_number()
        data = self.pad_data(display_number)
        data["name"] = self.name_input.text().strip() or "Sin asignar"
        data["action"] = self.action_editor.get_action()
        self.profiles.save(self.profile_combo.currentText(), self.profile_data)
        self.refresh_pad_titles()
        self.statusBar().showMessage(
            f"PAD {display_number:02d} guardado.",
            3000,
        )

    def delete_current_pad(self) -> None:
        display_number = self.current_display_number()
        self.profile_data.setdefault("pads", {})[str(display_number)] = {
            "name": "Sin asignar",
            "icon": "",
            "action": {"type": "none"},
        }
        self.profiles.save(self.profile_combo.currentText(), self.profile_data)
        self.refresh_pad_titles()
        self.load_current_pad()

    def simulate_action(self) -> None:
        local_pad = self.selected_pad
        self.pad_widgets[local_pad].set_activity(True)
        QTimer.singleShot(
            220,
            lambda: self.pad_widgets[local_pad].set_activity(False),
        )
        self.execute_pad_action(
            self.current_display_number(),
            bypass_cooldown=True,
        )

    def execute_pad_action(
        self,
        display_number: int,
        bypass_cooldown: bool = False,
    ) -> None:
        now = time.monotonic()
        if not bypass_cooldown:
            previous = self.last_action_trigger.get(display_number, 0.0)
            if now - previous < self.action_cooldown_seconds:
                return
            self.last_action_trigger[display_number] = now

        data = self.pad_data(display_number)
        self._show_pad_osd(display_number)
        action = self._apply_global_paths(data.get("action", {"type": "none"}))
        action_type = str(action.get("type", "none"))
        if action_type == "ui_profile_next":
            self.next_profile(); return
        if action_type == "ui_profile_prev":
            self.previous_profile(); return
        if action_type == "ui_bank_a":
            self.change_bank("A"); return
        if action_type == "ui_bank_b":
            self.change_bank("B"); return
        if action_type == "ui_bank_toggle":
            self.change_bank("B" if self.active_bank == "A" else "A"); return
        if action_type == "photoshop_psd_selector":
            self._run_psd_selector(display_number, action); return

        self.action_engine.execute_async(
            action,
            on_success=lambda: QTimer.singleShot(
                0,
                lambda: self.handle_action_success(display_number),
            ),
            on_error=lambda message: QTimer.singleShot(
                0,
                lambda: self.handle_action_error(
                    display_number,
                    message,
                ),
            ),
        )


    def _run_psd_selector(self, display_number: int, action: dict) -> None:
        psd_path=str(action.get("psd_path", "")).strip()
        if not psd_path:
            self.handle_action_error(display_number, "No se seleccionó ninguna biblioteca PSD/PSB."); return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            items=list_psd_elements(
                psd_path,
                str(action.get("photoshop_path", "")),
                bool(action.get("open_if_closed", True)),
            )
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            self.handle_action_error(display_number, str(exc)); return
        QApplication.restoreOverrideCursor()
        if not items:
            self.handle_action_error(display_number, "El PSD no contiene capas o grupos seleccionables."); return
        picker=PsdElementPickerDialog(items, f"PAD {display_number:02d} · Elegir elementos PSD", self)
        # El selector debe aparecer incluso si MIDI Premium está minimizado o detrás de Photoshop.
        picker.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
        picker.show()
        picker.raise_()
        picker.activateWindow()
        if picker.exec() != QDialog.DialogCode.Accepted or not picker.selected_paths:
            return
        run_action=dict(action)
        if len(picker.selected_paths) == 1:
            run_action["type"]="photoshop_psd_element"
            run_action["element_path"]=list(picker.selected_paths[0])
        else:
            run_action["type"]="photoshop_psd_elements"
            run_action["element_paths"]=[list(path) for path in picker.selected_paths]
        self.action_engine.execute_async(
            run_action,
            on_success=lambda: QTimer.singleShot(0, lambda: self.handle_action_success(display_number)),
            on_error=lambda message: QTimer.singleShot(0, lambda: self.handle_action_error(display_number, message)),
        )

    def _apply_global_paths(self, action):
        if not isinstance(action, dict):
            return {"type": "none"}
        result = dict(action)
        if result.get("type") in {"photoshop_jsx", "photoshop_psd_element", "photoshop_psd_elements", "photoshop_psd_selector", "photoshop_psd_all"} and not str(result.get("photoshop_path", "")).strip():
            result["photoshop_path"] = str(self.settings.data.setdefault("paths", {}).get("photoshop_exe", "")).strip()
        if result.get("type") == "macro":
            result["steps"] = [self._apply_global_paths(step) for step in list(result.get("steps", []))]
        return result

    def handle_action_success(self, display_number: int) -> None:
        self.statusBar().showMessage(
            f"PAD {display_number:02d}: acción ejecutada.",
            2500,
        )

    def handle_action_error(
        self,
        display_number: int,
        message: str,
    ) -> None:
        self.statusBar().showMessage(
            f"PAD {display_number:02d}: {message}",
            6000,
        )

    def _remember_geometry(self, key: str) -> None:
        geometry = self.geometry()
        section = self.settings.data.setdefault("window", {}).setdefault(key, {})
        section.update(
            {
                "width": geometry.width(),
                "height": geometry.height(),
                "x": geometry.x(),
                "y": geometry.y(),
            }
        )

    def _restore_geometry(self, key: str, default_width: int, default_height: int) -> None:
        section = self.settings.data.setdefault("window", {}).get(key, {})
        width = int(section.get("width", default_width))
        height = int(section.get("height", default_height))
        self.resize(width, height)
        x, y = section.get("x"), section.get("y")
        if isinstance(x, int) and isinstance(y, int):
            self.move(x, y)

    def _apply_workspace_visibility(self) -> None:
        # La barra superior también se simplifica para que el ancho compacto
        # sea realmente reducido, sin cambiar el tamaño de los PAD.
        self.app_subtitle.setVisible(False)
        self.stream_button.setVisible(not self.compact_mode)
        self.profile_label.setVisible(False)
        self.add_profile_button.setVisible(True)

        if self.stream_mode:
            self.editor_panel.setVisible(False)
            self.midi_monitor.setVisible(False)
            self.compact_close_button.setVisible(False)
            return

        if self.compact_mode:
            self.editor_panel.setVisible(False)
            self.midi_monitor.setVisible(False)
            self.compact_close_button.setVisible(False)
            self.knob_panel.set_compact_mode(True)
        else:
            self.editor_panel.setVisible(True)
            self.midi_monitor.setVisible(True)
            self.compact_close_button.setVisible(False)
            self.knob_panel.set_compact_mode(False)

    def open_compact_editor(self) -> None:
        if not self.compact_mode or self.stream_mode:
            return
        if not self.compact_editor_open:
            self._remember_geometry("compact")
        self.compact_editor_open = True
        self._apply_workspace_visibility()
        normal = self.settings.data.setdefault("window", {}).get("normal", {})
        target_width = max(int(normal.get("width", 1180)), 1080)
        target_height = max(self.height(), int(normal.get("height", 760)))
        self.setMaximumHeight(16777215)
        self.setMinimumSize(860, 560)
        self.resize(target_width, target_height)

    def close_compact_editor(self) -> None:
        if not self.compact_mode:
            return
        self.compact_editor_open = False
        self._apply_workspace_visibility()
        self.setMinimumSize(560, 500)
        self.setMaximumHeight(620)
        self._restore_geometry("compact", 635, 560)

    def set_compact_mode(self, enabled: bool, initial: bool = False) -> None:
        enabled = bool(enabled)
        if not initial and enabled == self.compact_mode:
            self.compact_checkbox.blockSignals(True)
            self.compact_checkbox.setChecked(enabled)
            self.compact_checkbox.blockSignals(False)
            return

        if not initial:
            if enabled:
                self._remember_geometry("normal")
            else:
                self._remember_geometry("compact")

        self.compact_mode = enabled
        self.compact_editor_open = False
        self.compact_checkbox.blockSignals(True)
        self.compact_checkbox.setChecked(enabled)
        self.compact_checkbox.blockSignals(False)

        self.settings.data.setdefault("workspace", {})["compact_mode"] = enabled

        if enabled:
            self.setMinimumSize(560, 500)
            self.setMaximumHeight(620)
            self._restore_geometry("compact", 635, 560)
            self.statusBar().showMessage(
                "Modo compacto: clic derecho en un PAD o perilla para editar.",
                4000,
            )
        else:
            self.setMinimumSize(860, 560)
            self._restore_geometry("normal", 1180, 760)

        self._apply_workspace_visibility()
        self.settings.save()

    def set_stream_mode(self, enabled: bool) -> None:
        self.stream_mode = bool(enabled)
        self.stream_button.setChecked(self.stream_mode)
        self.settings.data["workspace"]["stream_mode"] = self.stream_mode
        self.settings.save()
        self.stream_button.setText(
            "Salir de Modo Stream" if self.stream_mode else "Modo Stream"
        )
        self._apply_workspace_visibility()


    def _start_midi_learn(self, key: str) -> None:
        self._midi_learn_target = str(key)
        self.statusBar().showMessage("MIDI Learn: presiona ahora el botón físico que quieras asignar…", 7000)

    def _start_joystick_detect(self, axis: str) -> None:
        self._joystick_detect_axis = str(axis)
        self._midi_learn_target = None
        self.statusBar().showMessage(f"Detección de palanca ({axis}): mueve ahora ese eje…", 7000)

    def open_app_settings(self) -> None:
        dialog = AppSettingsDialog(self.settings.data, self)
        self._midi_learn_dialog = dialog
        dialog.midi_learn_requested.connect(self._start_midi_learn)
        dialog.joystick_detect_requested.connect(self._start_joystick_detect)
        dialog.check_updates_requested.connect(lambda: self.check_for_updates(interactive=True))
        accepted = dialog.exec() == QDialog.DialogCode.Accepted
        self._midi_learn_target = None
        self._joystick_detect_axis = None
        self._midi_learn_dialog = None
        if not accepted:
            return
        result = dialog.result_settings()
        self.settings.data.setdefault("paths", {}).update(result.get("paths", {}))
        self.settings.data.setdefault("workspace", {}).update(result.get("workspace", {}))
        self.settings.data.setdefault("updates", {}).update(result.get("updates", {}))
        midi_result = result.get("midi", {})
        if isinstance(midi_result, dict):
            self.settings.data.setdefault("midi", {}).update(midi_result)
        self.settings.save()
        self._sync_windows_startup(bool(self.settings.data.setdefault("workspace", {}).get("start_with_windows", False)))
        self.action_editor.global_paths = dict(self.settings.data.get("paths", {}))
        if hasattr(self.action_editor, "photoshop_path"):
            self.action_editor.photoshop_path.setPlaceholderText(
                str(self.settings.data.get("paths", {}).get("photoshop_exe", "")) or "Ruta global de Photoshop"
            )
        self.statusBar().showMessage("Configuración guardada.", 3000)

    def check_for_updates(self, interactive: bool = True) -> None:
        if interactive:
            self.statusBar().showMessage("Buscando actualizaciones…", 3000)
        if not self.update_service.check_async(interactive=interactive) and interactive:
            QMessageBox.information(self, "MIDI Premium 2", "Ya hay una comprobación de actualizaciones en curso.")

    def _on_update_check_finished(self, manifest: object, error: str, interactive: bool) -> None:
        data = manifest if isinstance(manifest, dict) else {}
        if error:
            if interactive:
                QMessageBox.information(self, "MIDI Premium 2", f"No se pudo comprobar actualizaciones.\n\n{error}")
            return
        latest = str(data.get("version", "") or "").strip()
        notes = str(data.get("notes", "") or "").strip()
        if update_available(data):
            self._pending_update_manifest = dict(data)
            message = f"Hay una actualización disponible.\n\nVersión actual: {current_version()}\nNueva versión: {latest}"
            if notes:
                message += f"\n\nNovedades:\n{notes}"
            message += "\n\n¿Quieres descargarla e instalarla ahora?"
            answer = QMessageBox.question(self, "MIDI Premium 2", message, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if answer == QMessageBox.StandardButton.Yes:
                self._start_update_download()
        elif interactive:
            QMessageBox.information(self, "MIDI Premium 2", f"Ya tienes la versión más reciente.\n\nVersión actual: {current_version()}")

    def _start_update_download(self) -> None:
        if not self._pending_update_manifest:
            return
        self.statusBar().showMessage("Descargando actualización…")
        if not self.update_service.download_setup_async(self._pending_update_manifest):
            QMessageBox.information(self, "MIDI Premium 2", "Ya hay una descarga de actualización en curso.")

    def _on_update_download_progress(self, value: int) -> None:
        self.statusBar().showMessage(f"Descargando actualización… {value}%")

    def _on_update_download_finished(self, installer_path: str, error: str) -> None:
        if error:
            QMessageBox.warning(self, "MIDI Premium 2", f"No se pudo descargar la actualización.\n\n{error}")
            self.statusBar().showMessage("Error al descargar la actualización.", 5000)
            return
        try:
            launch_installer(installer_path)
        except Exception as exc:
            QMessageBox.warning(self, "MIDI Premium 2", f"No se pudo iniciar el instalador.\n\n{exc}")
            return
        self._force_quit = True
        self.tray_icon.hide()
        QApplication.instance().quit()

    def _sync_windows_startup(self, enabled: bool) -> None:
        """Activa/desactiva el inicio automático para el usuario actual."""
        if os.name != "nt":
            return
        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
                if enabled:
                    # En una build PyInstaller, sys.executable YA es MIDI Premium 2.exe.
                    # En modo fuente seguimos usando pythonw + main.py.
                    if bool(getattr(sys, "frozen", False)):
                        command = f'"{sys.executable}"'
                    else:
                        pythonw = DEV_ROOT / "runtime" / "venv" / "Scripts" / "pythonw.exe"
                        executable = pythonw if pythonw.exists() else __import__("pathlib").Path(sys.executable)
                        main_py = DEV_ROOT / "main.py"
                        command = f'"{executable}" "{main_py}"'
                    winreg.SetValueEx(key, "MIDI Premium 2", 0, winreg.REG_SZ, command)
                else:
                    try:
                        winreg.DeleteValue(key, "MIDI Premium 2")
                    except FileNotFoundError:
                        pass
        except Exception as exc:
            self.statusBar().showMessage(f"No se pudo actualizar Inicio con Windows: {exc}", 6000)

    def _setup_tray(self) -> None:
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(QIcon(str(UI_ICON_DIR / "midi_connected.svg")))
        self.tray_icon.setToolTip("MIDI Premium 2")
        menu = QMenu(self)
        show_action = menu.addAction("Abrir MIDI Premium 2")
        show_action.triggered.connect(self.show_from_tray)
        menu.addSeparator()
        quit_action = menu.addAction("Salir")
        quit_action.triggered.connect(self.quit_from_tray)
        self.tray_icon.setContextMenu(menu)
        self.tray_icon.activated.connect(self._tray_activated)
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray_icon.show()

    def _tray_activated(self, reason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self.show_from_tray()

    def show_from_tray(self) -> None:
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def quit_from_tray(self) -> None:
        self._force_quit = True
        self.close()

    def _save_live_geometry(self) -> None:
        if self.isMinimized() or not self.isVisible():
            return
        key = "compact" if self.compact_mode else "normal"
        self._remember_geometry(key)
        geometry = self.geometry()
        self.settings.data.setdefault("window", {}).update({
            "width": geometry.width(), "height": geometry.height(),
            "x": geometry.x(), "y": geometry.y(),
        })
        self.settings.save()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if hasattr(self, "toast_label") and self.toast_label.isVisible():
            self.toast_label.move(max(8, (self.width()-self.toast_label.width())//2), max(8, self.height()-self.toast_label.height()-58))
        if hasattr(self, "_geometry_save_timer"):
            self._geometry_save_timer.start(300)

    def moveEvent(self, event) -> None:
        super().moveEvent(event)
        if hasattr(self, "_geometry_save_timer"):
            self._geometry_save_timer.start(300)

    def changeEvent(self, event) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.WindowStateChange and self.isMinimized():
            self._save_live_geometry()
            if bool(self.settings.data.setdefault("workspace", {}).get("minimize_to_tray", True)) and QSystemTrayIcon.isSystemTrayAvailable():
                QTimer.singleShot(0, self.hide)
                if not bool(self.settings.data.setdefault("workspace", {}).get("tray_hint_shown", False)):
                    self.tray_icon.showMessage(
                        "MIDI Premium 2",
                        "La aplicación sigue ejecutándose en segundo plano.",
                        QSystemTrayIcon.MessageIcon.Information,
                        2200,
                    )
                    self.settings.data["workspace"]["tray_hint_shown"] = True
                    self.settings.save()

    def closeEvent(self, event: QCloseEvent) -> None:
        geometry = self.geometry()
        if self.compact_mode and not self.compact_editor_open:
            self._remember_geometry("compact")
        elif not self.compact_mode:
            self._remember_geometry("normal")

        # Mantener también los campos antiguos para compatibilidad.
        self.settings.data["window"].update(
            {
                "width": geometry.width(),
                "height": geometry.height(),
                "x": geometry.x(),
                "y": geometry.y(),
            }
        )
        self.settings.save()
        self.midi_engine.shutdown()
        self.obs_engine.shutdown()
        self.continuous_engine.shutdown()
        event.accept()
