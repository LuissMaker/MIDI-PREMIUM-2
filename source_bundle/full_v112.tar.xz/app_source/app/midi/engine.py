from __future__ import annotations

import logging
from threading import RLock
from typing import Any

import mido
from PySide6.QtCore import QObject, QTimer, Signal, Slot

from app.midi.event import MidiEvent


class MidiEngine(QObject):
    devices_changed = Signal(list)
    connected = Signal(str)
    disconnected = Signal(str)
    event_received = Signal(object)
    error_occurred = Signal(str)

    def __init__(
        self,
        logger: logging.Logger,
        reconnect_interval_ms: int = 3000,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self.logger = logger
        self._input: Any | None = None
        self._device_name = ""
        self._preferred_device = ""
        self._auto_reconnect = True
        self._lock = RLock()

        self._reconnect_timer = QTimer(self)
        self._reconnect_timer.setInterval(max(1000, int(reconnect_interval_ms)))
        self._reconnect_timer.timeout.connect(self._reconnect_if_needed)
        self._reconnect_timer.start()

    @property
    def is_connected(self) -> bool:
        with self._lock:
            return self._input is not None

    def refresh_devices(self) -> list[str]:
        try:
            devices = list(mido.get_input_names())
        except Exception as exc:
            message = f"No se pudieron leer los dispositivos MIDI: {exc}"
            self.logger.exception(message)
            self.error_occurred.emit(message)
            devices = []
        self.devices_changed.emit(devices)
        return devices

    @staticmethod
    def choose_default_device(devices: list[str], preferred: str = "") -> str:
        if preferred and preferred in devices:
            return preferred
        for device in devices:
            lowered = device.lower()
            if "mpk mini" in lowered or "akai mpk" in lowered:
                return device
        return devices[0] if devices else ""

    def connect_device(self, device_name: str) -> bool:
        device_name = device_name.strip()
        if not device_name:
            self.error_occurred.emit("Selecciona un dispositivo MIDI.")
            return False

        self.disconnect_device("Cambiando dispositivo.", emit_signal=False)

        try:
            opened = mido.open_input(device_name, callback=self._mido_callback)
        except Exception as exc:
            message = f"No se pudo conectar con «{device_name}»: {exc}"
            self.logger.exception(message)
            self.error_occurred.emit(message)
            return False

        with self._lock:
            self._input = opened
            self._device_name = device_name
            self._preferred_device = device_name

        self.logger.info("MIDI conectado: %s", device_name)
        self.connected.emit(device_name)
        return True

    def disconnect_device(
        self,
        reason: str = "Desconectado por el usuario.",
        emit_signal: bool = True,
    ) -> None:
        with self._lock:
            port = self._input
            previous = self._device_name
            self._input = None
            self._device_name = ""

        if port is not None:
            try:
                port.close()
            except Exception:
                self.logger.exception("Error cerrando MIDI.")

        if previous and emit_signal:
            self.disconnected.emit(reason)

    def configure_reconnect(self, preferred: str, enabled: bool) -> None:
        self._preferred_device = preferred.strip()
        self._auto_reconnect = bool(enabled)

    def auto_connect(self) -> bool:
        devices = self.refresh_devices()
        selected = self.choose_default_device(devices, self._preferred_device)
        if not selected:
            self.disconnected.emit("No se encontró ningún dispositivo MIDI.")
            return False
        return self.connect_device(selected)

    def shutdown(self) -> None:
        self._reconnect_timer.stop()
        self.disconnect_device("Cierre de la aplicación.", emit_signal=False)

    def _mido_callback(self, message: Any) -> None:
        try:
            event = MidiEvent.from_mido(message)
            self.logger.debug("MIDI RX | %s", event.raw_text)
            self.event_received.emit(event)
        except Exception as exc:
            message = f"Error procesando MIDI: {exc}"
            self.logger.exception(message)
            self.error_occurred.emit(message)

    def _reconnect_if_needed(self) -> None:
        if not self._auto_reconnect or self.is_connected:
            return
        devices = self.refresh_devices()
        selected = self.choose_default_device(devices, self._preferred_device)
        if selected:
            self.connect_device(selected)
