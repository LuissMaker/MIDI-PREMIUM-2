from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class MidiEvent:
    type: str
    channel: int | None = None
    note: int | None = None
    velocity: int | None = None
    control: int | None = None
    value: int | None = None
    program: int | None = None
    pitch: int | None = None
    raw_text: str = ""

    @classmethod
    def from_mido(cls, message: Any) -> "MidiEvent":
        return cls(
            type=str(getattr(message, "type", "unknown")),
            channel=getattr(message, "channel", None),
            note=getattr(message, "note", None),
            velocity=getattr(message, "velocity", None),
            control=getattr(message, "control", None),
            value=getattr(message, "value", None),
            program=getattr(message, "program", None),
            pitch=getattr(message, "pitch", None),
            raw_text=str(message),
        )

    @property
    def channel_display(self) -> int | None:
        return None if self.channel is None else self.channel + 1

    @property
    def is_press(self) -> bool:
        if self.type == "note_on":
            return (self.velocity or 0) > 0
        if self.type == "control_change":
            return (self.value or 0) > 0
        return False

    @property
    def is_release(self) -> bool:
        if self.type == "note_off":
            return True
        if self.type == "note_on":
            return (self.velocity or 0) == 0
        if self.type == "control_change":
            return (self.value or 0) == 0
        return False

    def summary(self) -> str:
        channel = (
            f"Canal {self.channel_display}"
            if self.channel_display is not None
            else "Sin canal"
        )
        if self.type in {"note_on", "note_off"}:
            return f"{self.type} · {channel} · Nota {self.note} · Velocidad {self.velocity}"
        if self.type == "control_change":
            return f"control_change · {channel} · CC {self.control} · Valor {self.value}"
        if self.type == "program_change":
            return f"program_change · {channel} · Programa {self.program}"
        if self.type == "pitchwheel":
            return f"pitchwheel · {channel} · Pitch {self.pitch}"
        return f"{self.type} · {channel}"
