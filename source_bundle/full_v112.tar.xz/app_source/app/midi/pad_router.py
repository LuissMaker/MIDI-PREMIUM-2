from __future__ import annotations

from dataclasses import dataclass

from app.midi.event import MidiEvent


@dataclass(frozen=True, slots=True)
class PadRoute:
    bank: str
    local_pad: int
    display_pad: int


class MpkMiniPadRouter:
    """Fixed router for the user's AKAI MPK Mini MK3 preset.

    Primary map:
      Channel 10 (mido channel=9), Control Change:
      PAD 1–4 -> CC 20–23
      PAD 5–8 -> CC 16–19

    Fallback map:
      Bank A notes 36–43
      Bank B notes 44–51
    """

    _CC_MAP: dict[int, PadRoute] = {
        20: PadRoute("CURRENT", 1, 1),
        21: PadRoute("CURRENT", 2, 2),
        22: PadRoute("CURRENT", 3, 3),
        23: PadRoute("CURRENT", 4, 4),
        16: PadRoute("CURRENT", 5, 5),
        17: PadRoute("CURRENT", 6, 6),
        18: PadRoute("CURRENT", 7, 7),
        19: PadRoute("CURRENT", 8, 8),
    }

    _NOTE_MAP: dict[int, PadRoute] = {
        40: PadRoute("A", 1, 1),
        41: PadRoute("A", 2, 2),
        42: PadRoute("A", 3, 3),
        43: PadRoute("A", 4, 4),
        36: PadRoute("A", 5, 5),
        37: PadRoute("A", 6, 6),
        38: PadRoute("A", 7, 7),
        39: PadRoute("A", 8, 8),
        48: PadRoute("B", 1, 9),
        49: PadRoute("B", 2, 10),
        50: PadRoute("B", 3, 11),
        51: PadRoute("B", 4, 12),
        44: PadRoute("B", 5, 13),
        45: PadRoute("B", 6, 14),
        46: PadRoute("B", 7, 15),
        47: PadRoute("B", 8, 16),
    }

    def route(self, event: MidiEvent) -> PadRoute | None:
        if event.type == "control_change":
            # The pads were verified on MIDI channel 10.
            if event.channel != 9 or event.control is None:
                return None
            return self._CC_MAP.get(event.control)

        if event.type in {"note_on", "note_off"}:
            if event.note is None:
                return None
            return self._NOTE_MAP.get(event.note)

        return None
