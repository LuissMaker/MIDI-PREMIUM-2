from __future__ import annotations
import logging, math, threading
from typing import Any
from PySide6.QtCore import QObject,QTimer,Signal

class ContinuousActionEngine(QObject):
    value_applied=Signal(int,int,float)
    error_occurred=Signal(int,str)
    def __init__(self,obs_engine,logger:logging.Logger,update_interval_ms:int=33,parent=None):
        super().__init__(parent); self.obs_engine=obs_engine; self.logger=logger
        self._latest={}; self._sent={}; self._busy=set(); self._lock=threading.RLock()
        self._timer=QTimer(self); self._timer.setInterval(max(20,int(update_interval_ms))); self._timer.timeout.connect(self._flush); self._timer.start()
    def update_knob(self,knob:int,value:int,config:dict[str,Any])->None:
        with self._lock: self._latest[int(knob)]=(max(0,min(127,int(value))),dict(config))
    def shutdown(self): self._timer.stop()
    def _flush(self):
        jobs=[]
        with self._lock:
            for knob,(value,cfg) in self._latest.items():
                if knob in self._busy or self._sent.get(knob)==value: continue
                self._busy.add(knob); jobs.append((knob,value,cfg))
        for job in jobs: threading.Thread(target=self._worker,args=job,daemon=True,name=f'Knob-{job[0]}').start()
    def _worker(self,knob,value,cfg):
        try:
            typ=str(cfg.get('type','none')); db=self.midi_to_db(value,cfg)
            if typ=='obs_volume':
                source=str(cfg.get('source','')).strip()
                if not source: raise RuntimeError(f'K{knob}: selecciona una fuente de OBS.')
                self.obs_engine.set_input_volume_db(source,db)
            elif typ!='none': raise RuntimeError(f'K{knob}: acción continua no compatible: {typ}')
            with self._lock: self._sent[knob]=value
            self.value_applied.emit(knob,value,db)
        except Exception as exc:
            msg=str(exc) or exc.__class__.__name__; self.logger.exception('Knob %s failed: %s',knob,msg); self.error_occurred.emit(knob,msg)
        finally:
            with self._lock: self._busy.discard(knob)
    @staticmethod
    def midi_to_db(value:int,cfg:dict[str,Any])->float:
        value=max(0,min(127,int(value)))
        if bool(cfg.get('invert',False)): value=127-value
        if value<=0: return -100.0
        min_db=float(cfg.get('minimum_db',-60.0)); max_db=float(cfg.get('maximum_db',0.0))
        if min_db>max_db: min_db,max_db=max_db,min_db
        if str(cfg.get('curve','obs'))=='linear_db':
            useful=(value-1)/126.0; return min_db+useful*(max_db-min_db)
        x=value/127.0; natural=max(min_db,min(0.0,40.0*math.log10(x)))
        if max_db==0.0: return natural
        ratio=(natural-min_db)/max(0.0001,0.0-min_db)
        return min_db+ratio*(max_db-min_db)
