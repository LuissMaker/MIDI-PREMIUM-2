from __future__ import annotations
from dataclasses import dataclass
from app.midi.event import MidiEvent

@dataclass(frozen=True, slots=True)
class KnobRoute:
    knob:int
    control:int
    value:int

class MpkMiniKnobRouter:
    _MAP={70:1,71:2,72:3,73:4,74:5,75:6,76:7,77:8}
    def route(self,event:MidiEvent)->KnobRoute|None:
        if event.type!='control_change' or event.channel!=0 or event.control is None or event.value is None:
            return None
        knob=self._MAP.get(int(event.control))
        if knob is None: return None
        return KnobRoute(knob,int(event.control),max(0,min(127,int(event.value))))
