# MIDI Premium 2 — Fase 1.6.2 Fix

- Perillas realmente movidas debajo de los pads.
- Sección plegada por defecto.
- Configuración en tarjetas compactas de dos columnas.
- Corregida la conexión de resultados de fuentes OBS con el editor.
- Añadido soporte para fuentes dentro de grupos de OBS.


## Alternar visibilidad con un solo pad

En las acciones `OBS: Mostrar fuente` y `OBS: Ocultar fuente` aparece:

`Alternar con cada pulsación`

Al activarlo:
- Primera pulsación: oculta la fuente si está visible.
- Segunda pulsación: la vuelve a mostrar.
- El mismo pad controla ambos estados.

## Ejecutar JSX en Photoshop 2020

1. Selecciona un pad.
2. En Tipo de acción elige `Photoshop 2020: Ejecutar JSX`.
3. Pulsa `Examinar…` y selecciona un archivo `.jsx`.
4. La ruta de `Photoshop.exe` es opcional. Puede ayudar si Photoshop no se inicia automáticamente.
5. Deja activa la opción `Abrir Photoshop si está cerrado` y guarda el pad.

Se incluye un script de prueba en:

`Scripts\Photoshop\Crear_Documento_Base_1080x1300_300ppp.jsx`

Este script crea un documento RGB de 1080 × 1300 píxeles, 300 ppp, 8 bits y fondo transparente.


### Corrección 0.6.6
La ejecución de JSX usa ahora un puente VBScript COM compatible con Photoshop 2020. Si Photoshop o el propio script devuelven un error, MIDI Premium 2 lo mostrará en pantalla.
