@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title MIDI Premium 2 - Preparar entorno

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>&1
    if %errorlevel% neq 0 (
        echo No se encontro Python 3.11 o superior.
        pause
        exit /b 1
    )
    set "PYTHON=python"
)

if not exist "runtime\venv\Scripts\python.exe" (
    echo Creando entorno local...
    %PYTHON% -m venv "runtime\venv"
)

"runtime\venv\Scripts\python.exe" -m pip install --upgrade pip
"runtime\venv\Scripts\python.exe" -m pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo Fallo la instalacion.
    pause
    exit /b 1
)

echo Entorno listo.
pause
