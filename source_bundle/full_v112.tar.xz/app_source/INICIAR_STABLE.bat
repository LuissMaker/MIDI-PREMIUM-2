@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title MIDI Premium 2

if not exist "runtime\venv\Scripts\python.exe" (
    call INSTALAR_STABLE.bat
)

"runtime\venv\Scripts\python.exe" main.py

if %errorlevel% neq 0 (
    echo.
    echo MIDI Premium 2 termino con un error.
    echo Revisa los logs en %%APPDATA%%\MIDI Premium 2\logs\latest.log
    pause
)
