#target photoshop
app.bringToFront();

var ancho = 1080;
var alto = 1300;
var resolucion = 300;
var nombre = "Base 1080x1300";

app.documents.add(
    UnitValue(ancho, "px"),
    UnitValue(alto, "px"),
    resolucion,
    nombre,
    NewDocumentMode.RGB,
    DocumentFill.TRANSPARENT,
    1.0,
    BitsPerChannelType.EIGHT
);
