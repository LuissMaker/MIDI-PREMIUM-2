MIDI Premium 2 v1.0.3 Stable

Cambios principales: OSD BANK corregido, icono Configuración adaptado y control de perfiles/BANK mediante palanca configurable.

MIDI Premium 2 — v1.0.2 Stable
================================

Actualización de la primera versión estable centrada en funcionamiento en segundo plano y feedback visual.

NOVEDADES v1.0.2
----------------
1. Inicio oculto en bandeja
   - Nueva opción: "Iniciar oculto en la bandeja".
   - Activada por defecto.
   - MIDI, acciones y perfiles siguen funcionando aunque la ventana principal no esté visible.
   - Doble clic en el icono de bandeja vuelve a abrir MIDI Premium 2.

2. OSD de PAD
   - Nueva opción: "Mostrar acciones de PAD en pantalla".
   - Al pulsar un PAD aparece un aviso flotante centrado encima de otras aplicaciones.
   - Muestra el nombre configurado del PAD.
   - Puede mostrar el icono del PAD y el BANK.
   - La duración es configurable.

3. OSD de perillas
   - Nueva opción: "Mostrar perillas en pantalla".
   - Una perilla actualiza el mismo OSD mientras gira, sin crear ventanas nuevas.
   - Para OBS Volumen muestra porcentaje y dB.
   - El OSD desaparece automáticamente al dejar de mover la perilla.
   - Las perillas ahora admiten un nombre opcional, por ejemplo "Micrófono".

4. Inicio con Windows
   - Se conserva "Iniciar MIDI Premium 2 con Windows".
   - Corregido el registro de inicio automático para builds compiladas con PyInstaller.

AJUSTES
-------
Rutas > Aplicación:
- Al minimizar, ocultar en la bandeja del sistema.
- Iniciar MIDI Premium 2 con Windows.
- Iniciar oculto en la bandeja.
- Mostrar acciones de PAD en pantalla.
- Mostrar perillas en pantalla.
- Mostrar icono del PAD.
- Mostrar BANK.
- Duración del OSD de PAD y perilla.

La configuración y los presets continúan guardándose en:
%APPDATA%\MIDI Premium 2

La integración Photoshop/PSD, presets, BANK A/B, MIDI Learn y demás funciones de v1.0.0 se mantienen.


v1.0.6: perfiles con iconos editables, OSD de perfil con icono y correccion de aislamiento BANK A/B.


v1.0.6: modo compacto por icono, perfiles duplicables/eliminables, selector ampliado y OSD compacto dinámico.


v1.0.6: corrige el ancho dinámico del OSD para que acciones largas no se recorten.
