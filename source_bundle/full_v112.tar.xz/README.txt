MIDI Premium 2 v1.0.6 Portable Builder

1. Extrae esta carpeta completa.
2. Ejecuta BUILD_PORTABLE.bat.
3. El .exe portable quedará en dist\MIDI Premium 2\.
4. El ZIP portable quedará en release\MIDI_Premium_2_v1.0.6_Portable.zip.

Cambios v1.0.6:
- OSD de BANK A/B corregido.
- Botón de Configuración solo con icono, adaptado al tema oscuro.
- Configuración de Palanca / Joystick en Controles MIDI.
- Detección automática de eje horizontal/vertical.
- Acciones configurables por dirección.
- Umbral, zona central y cooldown configurables.
- Bloqueo hasta regresar al centro para evitar múltiples cambios.

Cambios v1.0.6:
- Modo compacto con boton de icono, sin checkbox/texto.
- Selector de perfiles ampliado para nombres largos.
- Duplicar y eliminar perfil con confirmacion.
- OSD mas compacto con ancho dinamico segun el contenido.
