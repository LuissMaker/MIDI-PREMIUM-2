MIDI PREMIUM 2 v1.0.6 - SETUP BUILDER CORREGIDO
=================================================

Este builder fuerza Python 3.11 x64 y evita reutilizar un entorno de Python 3.13.

USO:
1. Extrae TODO el ZIP en una carpeta normal.
2. Ejecuta BUILD_SETUP.bat.
3. El script comprobara que tienes Python 3.11 x64.
4. Compilara primero el portable.
5. Detectara Inno Setup 6 (incluyendo instalaciones hechas por WinGet).
6. El instalador final quedara en:

   release\MIDI_Premium_2_Setup_v1.0.6.exe

IMPORTANTE:
- No ejecutes archivos desde la carpeta build. Esa carpeta es temporal.
- El ejecutable correcto queda en dist\MIDI Premium 2\
- Si ya existia .buildvenv creado con Python 3.13, este builder lo detecta y lo recrea.

REQUISITOS:
- Windows 10/11 x64
- Python 3.11 x64
- Inno Setup 6 (el builder intentara localizarlo o instalarlo con WinGet)
