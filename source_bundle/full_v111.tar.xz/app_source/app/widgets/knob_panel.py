from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)


class KnobMini(QFrame):
    clicked = Signal(int)
    context_requested = Signal(int)

    def __init__(self, knob: int, parent=None) -> None:
        super().__init__(parent)
        self.knob = knob
        self.setMinimumSize(108, 58)
        self.setMaximumHeight(64)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 5, 8, 5)
        layout.setSpacing(1)
        self.title = QLabel(f"K{knob}")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setStyleSheet("font-weight:700; font-size:11pt;")
        self.value = QLabel("0")
        self.value.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.value.setObjectName("Muted")
        self.action = QLabel("Sin acción")
        self.action.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.action.setObjectName("Muted")
        self.action.setVisible(False)
        layout.addWidget(self.title)
        layout.addWidget(self.value)
        self.setStyleSheet("""
            QFrame { background:#1B2028; border:1px solid #2C3440; border-radius:9px; }
            QLabel { border:none; background:transparent; }
        """)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.knob)
            event.accept(); return
        if event.button() == Qt.MouseButton.RightButton:
            self.context_requested.emit(self.knob)
            event.accept(); return
        super().mousePressEvent(event)


class KnobCard(QFrame):
    def __init__(self, knob: int, parent=None) -> None:
        super().__init__(parent)
        self.knob = knob
        self.setObjectName("KnobCard")
        self.setMinimumHeight(185)
        self.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Fixed,
        )

        layout = QGridLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setHorizontalSpacing(8)
        layout.setVerticalSpacing(7)

        title = QLabel(f"K{knob}")
        title.setStyleSheet(
            "font-size: 12pt; font-weight: 700;"
        )

        self.value = QLabel("0 · silencio")
        self.value.setObjectName("Muted")
        self.value.setAlignment(Qt.AlignmentFlag.AlignRight)

        self.action = QComboBox()
        self.action.addItem("Sin acción", "none")
        self.action.addItem("OBS: Volumen", "obs_volume")

        self.source = QComboBox()
        self.source.setMinimumWidth(150)

        self.curve = QComboBox()
        self.curve.addItem("OBS recomendada", "obs")
        self.curve.addItem("Lineal en dB", "linear_db")

        self.invert = QCheckBox("Invertir")

        self.minimum = QDoubleSpinBox()
        self.minimum.setRange(-100.0, 0.0)
        self.minimum.setDecimals(1)
        self.minimum.setSingleStep(1.0)
        self.minimum.setValue(-60.0)
        self.minimum.setSuffix(" dB")
        self.minimum.setMinimumWidth(100)

        self.maximum = QDoubleSpinBox()
        self.maximum.setRange(-60.0, 12.0)
        self.maximum.setDecimals(1)
        self.maximum.setSingleStep(1.0)
        self.maximum.setValue(0.0)
        self.maximum.setSuffix(" dB")
        self.maximum.setMinimumWidth(100)

        layout.addWidget(title, 0, 0)
        layout.addWidget(self.value, 0, 1, 1, 3)

        layout.addWidget(QLabel("Acción"), 1, 0)
        layout.addWidget(self.action, 1, 1, 1, 3)

        layout.addWidget(QLabel("Fuente OBS"), 2, 0)
        layout.addWidget(self.source, 2, 1, 1, 3)

        layout.addWidget(QLabel("Curva"), 3, 0)
        layout.addWidget(self.curve, 3, 1, 1, 2)
        layout.addWidget(self.invert, 3, 3)

        layout.addWidget(QLabel("Mín."), 4, 0)
        layout.addWidget(self.minimum, 4, 1)
        layout.addWidget(QLabel("Máx."), 4, 2)
        layout.addWidget(self.maximum, 4, 3)

        self.setStyleSheet(
            """
            QFrame#KnobCard {
                background-color: #1D222B;
                border: 1px solid #343C49;
                border-radius: 10px;
            }
            QFrame#KnobCard QLabel {
                background: transparent;
                border: none;
            }
            """
        )


class KnobPanel(QFrame):
    save_requested = Signal()
    edit_requested = Signal(int)
    test_requested = Signal(int)
    context_requested = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("MonitorPanel")
        self.cards: dict[int, KnobCard] = {}
        self.minis: dict[int, KnobMini] = {}
        self.compact_mode = False
        self.last_values: dict[int, int] = {i: 0 for i in range(1, 9)}
        self.names: dict[int, str] = {i: "" for i in range(1, 9)}

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 8, 10, 8)
        outer.setSpacing(6)

        header = QHBoxLayout()

        title = QLabel("Perillas K1–K8")
        title.setObjectName("SectionTitle")

        self.summary = QLabel("Esperando movimiento MIDI")
        self.summary.setObjectName("Muted")

        self.toggle = QToolButton()
        self.toggle.setText("Mostrar")
        self.toggle.setCheckable(True)
        self.toggle.toggled.connect(self._toggle)

        header.addWidget(title)
        self.summary.setVisible(False)
        header.addWidget(self.summary, 1)
        header.addWidget(self.toggle)

        self.compact_container = QWidget()
        compact_grid = QGridLayout(self.compact_container)
        compact_grid.setContentsMargins(0, 2, 0, 2)
        compact_grid.setHorizontalSpacing(8)
        compact_grid.setVerticalSpacing(8)
        for knob in range(1, 9):
            mini = KnobMini(knob)
            mini.context_requested.connect(self.context_requested.emit)
            mini.clicked.connect(lambda n: self.summary.setText(f"K{n} seleccionado · clic derecho para editar"))
            self.minis[knob] = mini
            compact_grid.addWidget(mini, 0 if knob <= 4 else 1, (knob - 1) % 4)
        self.compact_container.setVisible(False)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.scroll.setMinimumHeight(410)
        self.scroll.setMaximumHeight(470)

        self.cards_container = QWidget()
        self.cards_container.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Maximum,
        )

        grid = QGridLayout(self.cards_container)
        grid.setContentsMargins(0, 2, 0, 2)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)

        for knob in range(1, 9):
            card = KnobCard(knob)
            self.cards[knob] = card
            row = (knob - 1) // 2
            column = (knob - 1) % 2
            grid.addWidget(card, row, column)

        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)

        self.scroll.setWidget(self.cards_container)

        self.save_button = QPushButton(
            "Guardar configuración de perillas"
        )
        self.save_button.clicked.connect(
            self.save_requested.emit
        )

        outer.addLayout(header)
        outer.addWidget(self.compact_container)
        outer.addWidget(self.scroll)
        outer.addWidget(self.save_button)

        self.scroll.setVisible(False)
        self.save_button.setVisible(False)

    def _toggle(self, visible: bool) -> None:
        if self.compact_mode:
            self.compact_container.setVisible(visible)
            self.scroll.setVisible(False)
            self.save_button.setVisible(False)
        else:
            self.compact_container.setVisible(False)
            self.scroll.setVisible(visible)
            self.save_button.setVisible(visible)
        self.toggle.setText("Ocultar" if visible else "Mostrar")
        if visible and not self.compact_mode:
            self.cards_container.adjustSize()
            self.scroll.viewport().updateGeometry()
            self.updateGeometry()

    def set_compact_mode(self, enabled: bool) -> None:
        self.compact_mode = bool(enabled)
        if self.compact_mode:
            self.toggle.setChecked(True)
            self._toggle(True)
        else:
            self.toggle.setChecked(False)
            self._toggle(False)

    def set_knob_config(self, knob: int, config: dict) -> None:
        self.names[int(knob)] = str(config.get("name", "") or "").strip()
        card = self.cards[int(knob)]
        action_index = card.action.findData(str(config.get("type", "none")))
        card.action.setCurrentIndex(max(0, action_index))
        source = str(config.get("source", ""))
        if source and card.source.findText(source) < 0:
            card.source.addItem(source)
        card.source.setCurrentText(source)
        curve_index = card.curve.findData(str(config.get("curve", "obs")))
        card.curve.setCurrentIndex(max(0, curve_index))
        card.invert.setChecked(bool(config.get("invert", False)))
        card.minimum.setValue(float(config.get("minimum_db", -60.0)))
        card.maximum.setValue(float(config.get("maximum_db", 0.0)))
        self._refresh_mini(knob)

    def _refresh_mini(self, knob: int) -> None:
        cfg = self.knob_config(knob)
        mini = self.minis[int(knob)]
        if cfg.get("type") == "obs_volume":
            source = str(cfg.get("source", "")).strip()
            custom_name = str(cfg.get("name", "") or "").strip()
            mini.action.setText(custom_name or ("OBS · " + (source or "Volumen")))
        else:
            mini.action.setText("Sin acción")

    def set_sources(self, sources: list[str]) -> None:
        for card in self.cards.values():
            current = card.source.currentText()

            card.source.blockSignals(True)
            card.source.clear()
            card.source.addItems(sources)

            if current in sources:
                card.source.setCurrentText(current)

            card.source.blockSignals(False)

    def set_config(self, knobs: dict) -> None:
        for number, card in self.cards.items():
            config = dict(
                knobs.get(
                    str(number),
                    knobs.get(number, {}),
                )
                or {}
            )

            self.names[int(number)] = str(config.get("name", "") or "").strip()

            action_index = card.action.findData(
                str(config.get("type", "none"))
            )
            card.action.setCurrentIndex(
                max(0, action_index)
            )

            source = str(config.get("source", ""))
            if source and card.source.findText(source) < 0:
                card.source.addItem(source)
            card.source.setCurrentText(source)

            curve_index = card.curve.findData(
                str(config.get("curve", "obs"))
            )
            card.curve.setCurrentIndex(
                max(0, curve_index)
            )

            card.invert.setChecked(
                bool(config.get("invert", False))
            )
            card.minimum.setValue(
                float(config.get("minimum_db", -60.0))
            )
            card.maximum.setValue(
                float(config.get("maximum_db", 0.0))
            )
            self._refresh_mini(number)

    def get_config(self) -> dict:
        result: dict[str, dict] = {}

        for number, card in self.cards.items():
            result[str(number)] = {
                "name": str(self.names.get(int(number), "")),
                "type": str(card.action.currentData()),
                "source": card.source.currentText().strip(),
                "curve": str(card.curve.currentData()),
                "invert": card.invert.isChecked(),
                "minimum_db": card.minimum.value(),
                "maximum_db": card.maximum.value(),
            }

        return result

    def knob_config(self, knob: int) -> dict:
        return self.get_config().get(
            str(int(knob)),
            {"type": "none"},
        )

    def update_value(
        self,
        knob: int,
        midi_value: int,
        db: float | None = None,
    ) -> None:
        self.last_values[int(knob)] = int(midi_value)
        percent = round(
            max(0, min(127, midi_value)) / 127 * 100
        )

        if midi_value == 0:
            text = "0 · silencio"
        elif db is None:
            text = f"{midi_value} · {percent}%"
        else:
            text = f"{midi_value} · {db:.1f} dB"

        self.cards[int(knob)].value.setText(text)
        mini_text = "0" if midi_value == 0 else (f"{percent}%" if db is None else f"{db:.1f} dB")
        self.minis[int(knob)].value.setText(mini_text)
        self.summary.setText(f"K{knob}: {text}")

    def set_error(self, knob: int, message: str) -> None:
        self.cards[int(knob)].value.setText("Error")
        self.minis[int(knob)].value.setText("Error")
        self.summary.setText(f"K{knob}: {message}")

    def last_value(self, knob: int) -> int:
        return int(self.last_values.get(int(knob), 0))

    def clear_knob(self, knob: int) -> None:
        self.set_knob_config(int(knob), {"name":"", "type":"none", "source":"", "curve":"obs", "invert":False, "minimum_db":-60.0, "maximum_db":0.0})

