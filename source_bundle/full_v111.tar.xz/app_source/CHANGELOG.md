# Changelog

## 1.1.1 Stable
- Limpieza visual del panel principal: menos bordes, menos texto repetido y cabecera más compacta.
- PADs compactos: se elimina el BANK repetido dentro de cada tarjeta.
- Perillas K1–K8 más ligeras y compactas en modo reducido.
- Mejor aprovechamiento vertical de la ventana compacta y menor espacio vacío.
- Estado MIDI simplificado y más discreto.
- OSD/overlay corregido: respeta márgenes seguros de pantalla, ancho dinámico y evita recortes en bordes/DPI.
- Se mantiene intacta la configuración del usuario y las asignaciones existentes.

# MIDI Premium 2 v1.1.0 Stable

- Sistema de actualizaciones mediante GitHub Releases.
- Comprobación automática al iniciar (configurable).
- Botón manual “Buscar actualizaciones ahora…” en Configuración.
- Descarga del instalador oficial y actualización conservando datos en AppData.
- Infraestructura de release preparada para GitHub Actions.

# MIDI Premium 2 v1.0.6 Stable

- Modo compacto ahora se alterna con un icono dedicado, sin checkbox/texto.
- Selector de perfiles más ancho y adaptable a nombres largos.
- Añadidas opciones Duplicar perfil y Eliminar perfil con confirmación.
- OSD más compacto y con ancho dinámico según el contenido.

- Perfiles con iconos editables y persistentes.
- Nuevo menú “Editar perfil…” para cambiar nombre e icono.
- Iconos de perfil visibles dentro del selector y en su menú contextual.
- OSD de cambio de perfil reducido a icono + nombre, sin texto adicional.
- Eliminadas las flechas laterales de navegación de perfiles; la palanca/MIDI Learn conserva la navegación.
- Incluida biblioteca inicial de iconos: Photoshop, Premiere Pro, After Effects, Animate, Steam, Telegram y Word.
- Corregido aislamiento de BANK: BANK B ya no ejecuta asignaciones de BANK A al pulsar el mismo PAD físico.

# v1.0.3 Stable

- Corregido OSD al cambiar BANK A / BANK B.
- Botón de Configuración reducido al icono y adaptado al tema oscuro.
- Nueva sección Palanca / Joystick en Configuración > Controles MIDI.
- Detección automática de eje horizontal/vertical (Pitch Wheel o CC).
- Acciones configurables para izquierda, derecha, arriba y abajo.
- Valores por defecto: perfiles anterior/siguiente y BANK A/B.
- Umbral, zona central y cooldown configurables.
- Bloqueo hasta volver al centro para evitar múltiples cambios por una sola inclinación.

# 1.0.2 Stable

- OSD más pequeño, centrado abajo, con icono y texto centrados.
- OSD al cambiar BANK y perfil.
- Renombrado de perfiles desde el selector (clic derecho).
- Botón Rutas renombrado a Configuración con icono.
- Icono MIDI junto al estado, coloreado verde/rojo según conexión.
- Comprobador MIDI en Configuración > Controles MIDI con último mensaje e historial.

# v1.0.1 Stable — Tray + OSD

- Inicio oculto en bandeja configurable y activado por defecto.
- OSD flotante para mostrar nombre, icono y BANK al pulsar un PAD.
- OSD dinámico para perillas con porcentaje y dB en OBS Volumen.
- Duraciones y elementos del OSD configurables desde Ajustes > Aplicación.
- Nombre opcional para perillas, persistente por preset.
- Corregido Inicio con Windows en builds PyInstaller para usar el .exe directamente.
- Se mantienen sin cambios las acciones Photoshop/PSD y la compatibilidad de perfiles v1.0.0.

# v0.7.2-dev — Compact Context

- Modo compacto activado por defecto.
- Perillas visibles automáticamente en modo compacto.
- Edición contextual por clic derecho para PADs y perillas.
- La configuración de PAD se abre como ventana independiente en compacto.
- Modo normal conservado.

## 0.7.1-dev — Compact Mode
- Añadido Modo compacto con casilla persistente.
- Mantiene el tamaño original de los PAD.
- Inspector de PAD temporal al hacer clic izquierdo en modo compacto.
- Geometrías normal/compacta independientes.
- Guardar/eliminar/cerrar inspector regresa a vista compacta.

# MIDI Premium 2

## 0.6.4-dev — Toggle Source Checkbox

- Conserva la corrección visual de perillas de la versión 0.6.3.
- Añadido checkbox “Alternar con cada pulsación”.
- Disponible en OBS: Mostrar fuente y OBS: Ocultar fuente.
- Con el checkbox activo, el mismo pad alterna Visible/Oculta.
- La opción se guarda dentro del perfil del pad.

## 0.6.6-dev — Photoshop JSX Bridge Fix

- Corregida la ejecución de JSX en Photoshop 2020.
- Sustituido el puente PowerShell por VBScript/COM.
- Ahora Photoshop debe confirmar la ejecución del script.
- Se muestran errores reales de `DoJavaScriptFile` cuando un JSX falla.
- Se conserva la selección independiente de un archivo JSX por pad.

## 0.6.5-dev — Photoshop JSX

- Nueva acción por pad: `Photoshop 2020: Ejecutar JSX`.
- Selector de archivos `.jsx` y `.js` desde la interfaz.
- Ruta opcional a `Photoshop.exe`.
- Opción para abrir Photoshop si está cerrado y esperar hasta 45 segundos.
- La ruta del script y la configuración se guardan dentro del perfil.
- Incluye el ejemplo `Scripts/Photoshop/Crear_Documento_Base_1080x1300_300ppp.jsx`.
- La integración utiliza automatización COM de Windows mediante PowerShell, sin dependencias nuevas de Python.

## 0.7.0-dev Macro Deck
- Nuevo tipo de acción: Macro con múltiples pasos ejecutados en orden.
- Editor visual de macros con añadir, editar, eliminar y reordenar pasos.
- Nueva acción "Esperar" (0.05 a 60 s) para sincronizar aplicaciones.
- Nueva acción "Escribir texto" mediante el motor de teclado existente.
- Las macros reutilizan todas las acciones existentes: hotkeys, archivos, URLs, Photoshop JSX y OBS.
- Compatibilidad mantenida con perfiles v0.6.6.

## 0.7.4-dev Banks Presets Copy
- Estado MIDI compacto con color coherente e icono junto al texto.
- Recarga/reconexión MIDI manual.
- Feedback inmediato de Bank y toast de Bank/preset.
- Navegación anterior/siguiente de presets desde UI y desde acciones de PAD.
- Acciones de Bank A/B/alternar asignables a PAD.
- Copiar PAD a otro destino con modos todo/acción/apariencia.
- Buscador e importación manual de SVG en el selector de iconos.
- Acceso desde el selector a la colección completa Icona Moon Bold UI.


## v1.0.6
- OSD: ancho dinámico robusto para icono + nombre + márgenes.
- Las acciones con nombres largos ya no se recortan; la cápsula solo crece horizontalmente lo necesario.
