@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title MIDI Premium 2 - Build Portable v1.1.1

set "VENV=.buildvenv"
set "VPY=%VENV%\Scripts\python.exe"

echo ==========================================================
echo MIDI Premium 2 v1.1.1 - GENERADOR PORTABLE
echo Python 3.11 x64 forzado

echo ==========================================================
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo [ERROR] No se encontro Python Launcher ^(py.exe^).
  echo Instala Python 3.11 x64 desde python.org.
  pause
  exit /b 1
)

rem Verificar que Python 3.11 x64 este disponible
py -3.11 -c "import sys,struct; assert sys.version_info[:2]==(3,11) and struct.calcsize('P')*8==64" >nul 2>&1
if errorlevel 1 (
  echo [ERROR] No encuentro Python 3.11 de 64 bits.
  echo.
  echo Comprueba con:
  echo   py -3.11 --version
  echo.
  echo Debe mostrar Python 3.11.x.
  pause
  exit /b 1
)

rem Si existe un entorno anterior, comprobar que realmente sea 3.11 x64.
if exist "%VPY%" (
  "%VPY%" -c "import sys,struct; assert sys.version_info[:2]==(3,11) and struct.calcsize('P')*8==64" >nul 2>&1
  if errorlevel 1 (
    echo [AVISO] El entorno anterior no es Python 3.11 x64. Se recreara.
    rmdir /s /q "%VENV%"
  )
)

if not exist "%VPY%" (
  echo [1/6] Creando entorno limpio con Python 3.11 x64...
  py -3.11 -m venv "%VENV%"
  if errorlevel 1 goto :fail
) else (
  echo [1/6] Entorno Python 3.11 x64 correcto.
)

echo [2/6] Verificando Python del entorno...
"%VPY%" -c "import sys,struct; print('Python:',sys.version.split()[0],'-',struct.calcsize('P')*8,'bits'); assert sys.version_info[:2]==(3,11) and struct.calcsize('P')*8==64"
if errorlevel 1 goto :fail

echo [3/6] Actualizando pip...
"%VPY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail

echo [4/6] Instalando dependencias...
"%VPY%" -m pip install -r "app_source\requirements.txt" pyinstaller==6.11.1
if errorlevel 1 goto :fail

echo [5/6] Compilando MIDI Premium 2...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
"%VPY%" -m PyInstaller --noconfirm --clean "MIDI_Premium_2.spec"
if errorlevel 1 goto :fail

if not exist "dist\MIDI Premium 2\MIDI Premium 2.exe" (
  echo [ERROR] PyInstaller termino pero no se encontro el ejecutable final.
  goto :fail
)

rem Comprobacion importante: el runtime generado debe ser Python 3.11, no python313.dll
if exist "dist\MIDI Premium 2\_internal\python313.dll" (
  echo [ERROR] Se genero python313.dll. El entorno de compilacion no es correcto.
  echo Borra .buildvenv y vuelve a ejecutar este archivo.
  goto :fail
)
if not exist "dist\MIDI Premium 2\_internal\python311.dll" (
  echo [AVISO] No se encontro python311.dll en la ruta esperada.
  echo Revisa el contenido de dist antes de instalar.
)

echo [6/6] Preparando ZIP portable...
if not exist release mkdir release
if exist "release\MIDI_Premium_2_v1.1.1_Portable.zip" del /q "release\MIDI_Premium_2_v1.1.1_Portable.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'dist\MIDI Premium 2\*' -DestinationPath 'release\MIDI_Premium_2_v1.1.1_Portable.zip' -Force"
if errorlevel 1 goto :fail

echo.
echo ==========================================================
echo LISTO
echo Ejecutable:
echo   %CD%\dist\MIDI Premium 2\MIDI Premium 2.exe
echo ZIP portable:
echo   %CD%\release\MIDI_Premium_2_v1.1.1_Portable.zip
echo ==========================================================
pause
exit /b 0

:fail
echo.
echo [ERROR] La compilacion fallo. Revisa el mensaje de arriba.
pause
exit /b 1
