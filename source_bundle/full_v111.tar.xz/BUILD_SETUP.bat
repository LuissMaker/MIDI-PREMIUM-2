@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MIDI Premium 2 - Setup v1.1.1

echo ==========================================================
echo MIDI Premium 2 v1.1.1 - GENERADOR DE INSTALADOR
echo ==========================================================
echo.

call BUILD_PORTABLE.bat
if errorlevel 1 exit /b 1

set "ISCC="
call :find_inno

if not defined ISCC (
  echo.
  echo Inno Setup 6 no esta instalado.
  where winget >nul 2>&1
  if not errorlevel 1 (
    echo Intentando instalar Inno Setup mediante winget...
    winget install --id JRSoftware.InnoSetup -e --accept-package-agreements --accept-source-agreements
    call :find_inno
  )
)

if not defined ISCC (
  echo [ERROR] No pude localizar Inno Setup 6.
  echo Puedes usar igualmente el portable generado en la carpeta release.
  echo Para crear el instalador, instala Inno Setup 6 y vuelve a ejecutar BUILD_SETUP.bat.
  pause
  exit /b 1
)

echo.
echo Compilando instalador...
"%ISCC%" "MIDI_Premium_2_Setup.iss"
if errorlevel 1 (
  echo [ERROR] Inno Setup no pudo generar el instalador.
  pause
  exit /b 1
)

echo.
echo ==========================================================
echo LISTO
echo Instalador generado:
echo   %CD%\release\MIDI_Premium_2_Setup_v1.1.1.exe
echo ==========================================================
pause
exit /b 0


goto :eof

:find_inno
rem Rutas clasicas
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

rem PATH
for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"

rem Registro de Windows (instalacion por usuario o por maquina)
for %%K in ("HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Inno Setup 6_is1" "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall\Inno Setup 6_is1" "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Inno Setup 6_is1") do (
  if not defined ISCC (
    for /f "tokens=2,*" %%A in ('reg query %%~K /v InstallLocation 2^>nul ^| find /i "InstallLocation"') do (
      if exist "%%B\ISCC.exe" set "ISCC=%%B\ISCC.exe"
    )
  )
)

rem Winget puede instalar paquetes en el perfil del usuario
if not defined ISCC if exist "%LOCALAPPDATA%\Microsoft\WinGet\Packages" (
  for /f "delims=" %%I in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Get-ChildItem -Path $env:LOCALAPPDATA\\Microsoft\\WinGet\\Packages -Filter ISCC.exe -File -Recurse -ErrorAction SilentlyContinue ^| Select-Object -First 1 -ExpandProperty FullName; if($p){$p}" 2^>nul') do set "ISCC=%%I"
)

rem Ultimo recurso: buscar en carpetas locales habituales sin recorrer todo el disco
if not defined ISCC (
  for /f "delims=" %%I in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$roots=@($env:LOCALAPPDATA+'\\Programs',$env:LOCALAPPDATA+'\\Microsoft\\WinGet\\Packages'); foreach($r in $roots){if(Test-Path $r){$p=Get-ChildItem $r -Filter ISCC.exe -File -Recurse -ErrorAction SilentlyContinue ^| Select-Object -First 1 -ExpandProperty FullName; if($p){$p; break}}}" 2^>nul') do set "ISCC=%%I"
)

if defined ISCC echo Inno Setup encontrado en: "%ISCC%"
exit /b 0
